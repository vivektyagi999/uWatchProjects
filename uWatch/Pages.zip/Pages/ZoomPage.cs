﻿using System;
using Xamarin.Forms;
using System.IO;
using System.Reflection;
using Acr.UserDialogs;
using UwatchPCL;

namespace uWatch
{
	//public interface IBaseUrl
	//{
	//	string Get();

	//}

	//public class BaseUrlWebView : WebView
	//{

	//}

	public class ZoomPage : ContentPage
	{
		string _orderImage;
		string logoutText;

		public ZoomPage(ImageSource source)
		{
			Title = "Asset Image";
			var a = (UriImageSource)source;
			var ImageSource = a.Uri.ToString();
		//	NavigationPage.SetHasNavigationBar(this, false);
			var browser = new CustomWebView();

			browser.BackgroundColor = Xamarin.Forms.Color.Black;
			//convert image from binary to string
			_orderImage = ImageSource;
				//"http://109.228.10.71/api/images/389bc97c-7966-451d-baa4-52a87f65fe1c.jpg";

			//create a string having the dynamic image source
			string htmlsource = "<style>img{display: inline; height: auto; margin: 0 auto; max-width: 100%;}img-container {position: relative;top: 20%; width:100%; height:300px; overflow:hidden; text-align:center;}img{ max-width:100%;width:100%;vertical-align: middle;}\n</style><html>\n<head>\n</head>\n<body style =\"background-color:black\">\n< div class=\"img-container\"> </div>\n<img src=" + _orderImage + " />\n</body>\n</html>";

			var htmlSource = new HtmlWebViewSource();

			htmlSource.Html = @htmlsource;

			if (Device.OS != TargetPlatform.iOS)
			{
				htmlSource.BaseUrl = DependencyService.Get<IBaseUrl>().Get();
			}

			browser.Source = htmlSource;

#if IOS
			logoutText = "Logout";
#else
#if ANDROID
			logoutText = "LOGOUT";
#else
#endif
#endif

			var img = new Image
			{
				//Source = ImageUtil.BackImage,
				HorizontalOptions = LayoutOptions.StartAndExpand,
				VerticalOptions = LayoutOptions.StartAndExpand
			};

			var imgNav = new Image
			{
				//Source = ImageUtil.ToolbarWhiteNavImage,
				HorizontalOptions = LayoutOptions.EndAndExpand,
				VerticalOptions = LayoutOptions.StartAndExpand,
				HeightRequest = 22,
				WidthRequest = 52
			};
			var imgLogout = new Label
			{
				Text = logoutText,
				FontSize = 16,
				TextColor = Color.White,
				FontAttributes = FontAttributes.Bold,
				HorizontalOptions = LayoutOptions.EndAndExpand,
				VerticalOptions = LayoutOptions.StartAndExpand
			};


			var layoutHavingLogout = new StackLayout { IsVisible = false, Padding = new Thickness(10, 5, 15, 0) };
			layoutHavingLogout.Children.Add(imgLogout);

			var layoutBack = new StackLayout { Padding = new Thickness(10, 0, 0, 0) };
			layoutBack.Children.Add(img);


			Grid grid = new Grid
			{
				VerticalOptions = LayoutOptions.FillAndExpand,
				RowDefinitions = {
					new RowDefinition { Height = new GridLength (40, GridUnitType.Absolute) },
					new RowDefinition { Height = new GridLength (1, GridUnitType.Star) }
				},
				ColumnDefinitions = {
					new ColumnDefinition { Width = new GridLength (1, GridUnitType.Star) },
				}
			};


			var tapGestureRecognizerNav = new TapGestureRecognizer();
			imgNav.GestureRecognizers.Add(tapGestureRecognizerNav);
			tapGestureRecognizerNav.Tapped += (object sender, EventArgs e) =>
			{
				imgNav.IsVisible = false;
				layoutHavingLogout.IsVisible = true;
			};


		//	grid.Children.Add(layoutBack, 0, 3, 0, 1);
		//	grid.Children.Add(imgNav, 0, 3, 0, 2);
		//	grid.Children.Add(layoutHavingLogout, 0, 3, 0, 2);
			grid.Children.Add(browser, 0, 3, 0, 1);


			//on clcik of back button
			var tapGestureRecognizerBack = new TapGestureRecognizer();
			img.GestureRecognizers.Add(tapGestureRecognizerBack);
			tapGestureRecognizerBack.Tapped += (object senders, EventArgs e1) =>
			{

				Navigation.PopModalAsync();
			};

			//on logout
			var tapGestureRecognizerLogout = new TapGestureRecognizer();
			imgLogout.GestureRecognizers.Add(tapGestureRecognizerLogout);
			tapGestureRecognizerLogout.Tapped += (object sender, EventArgs e) =>
			{
				//
				//HomeViewModel.LogOut();
				//Navigation.PushModalAsync(new LoginPage());

			};

			//this.Padding = new Thickness(0, 25, 0, 0);
			Content = browser;

			var tapGestureRecognizerNavS = new TapGestureRecognizer();
			Content.GestureRecognizers.Add(tapGestureRecognizerNavS);
			tapGestureRecognizerNavS.Tapped += (object sender, EventArgs e) =>
			{
				imgNav.IsVisible = true;
				layoutHavingLogout.IsVisible = false;

			};
			Content.BackgroundColor = Xamarin.Forms.Color.Black;
		}

	}
}