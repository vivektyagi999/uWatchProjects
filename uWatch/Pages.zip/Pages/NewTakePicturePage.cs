﻿using System;
using System.IO;
using System.Threading.Tasks;
using Acr.UserDialogs;
using FFImageLoading.Forms;
using uWatch.Controls;
using uWatch.ViewModels;
using UwatchPCL;
using UwatchPCL.Helpers;
using UwatchPCL.Model;
using Xamarin.Forms;
//using Android.Graphics;

namespace uWatch
{
	public class NewTakePicturePage : ContentPage
	{
		byte[] data;

		public string imgFromCam;
		public TakePictureViewModel ViewModel { get; set; }
		private DeviceAssetsModel Asset = new DeviceAssetsModel();
		public bool IsRotate;
		public NewTakePicturePage(TakePictureViewModel model, string ImageFromCamInAndroid)
		{
			try
			{
				Title = "Asset Details";
				MyController.fromAssetsToGallery = true;
				this.ViewModel = model;
				imgFromCam = ImageFromCamInAndroid;
				BindingContext = ViewModel;
				SetLayout();
			}
			catch { 
			}
		}
		private async void SetLayout()
		{


			var lblpurchaseDate = new Label { Text = "Purchase Date", FontSize = 18,TextColor = Color.Black,WidthRequest = MyController.ScreenWidth / 2 - 50,HeightRequest = 40 };
			var DatePickerPurchageDate = new DatePicker {WidthRequest = MyController.ScreenWidth/2-50,HeightRequest = 40 };
			var layoutPurchage = new StackLayout { HorizontalOptions = LayoutOptions.StartAndExpand,Spacing = 2 };
			layoutPurchage.Children.Add(lblpurchaseDate);
			layoutPurchage.Children.Add(DatePickerPurchageDate);


			var lblExpiryDate = new Label { Text = " Warranty Expiry",FontSize = 18, TextColor = Color.Black,WidthRequest = MyController.ScreenWidth / 2 - 50,HeightRequest = 40 };
			var DateExpiryDate = new DatePicker {WidthRequest = MyController.ScreenWidth / 2 - 50,HeightRequest = 40 };
			var layoutExpiry = new StackLayout { HorizontalOptions = LayoutOptions.EndAndExpand,Spacing = 2 };
			layoutExpiry.Children.Add(lblExpiryDate);
			layoutExpiry.Children.Add(DateExpiryDate);

			var layoutMainDate = new StackLayout { Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.FillAndExpand };
			layoutMainDate.Children.Add(layoutPurchage);
			layoutMainDate.Children.Add(layoutExpiry);

			var layoutDescription = new StackLayout { Spacing = 2,HeightRequest = 100 };
			var lblDesc = new Label { Text = "Description",FontSize = 18, TextColor = Color.Black };
			var lblHidekeyboard = new Label { Text = "Tap me to hide the keyboard", FontSize = 16, IsVisible = false,FontAttributes = FontAttributes.Italic, TextColor = Color.Red };
			var EditorDesc = new ExtendedEditor { HeightRequest = 90 };
			layoutDescription.Children.Add(lblDesc);
			layoutDescription.Children.Add(lblHidekeyboard);
			layoutDescription.Children.Add(EditorDesc);
	

			EditorDesc.Focused += (sender, e) =>
			{
				lblHidekeyboard.IsVisible = true;

			};
			EditorDesc.Unfocused += (sender, e) =>
			{
				lblHidekeyboard.IsVisible = false;

			};

			TapGestureRecognizer HideKeyboard = new TapGestureRecognizer();
			HideKeyboard.Tapped += async (object sender, EventArgs e) =>
			{
				EditorDesc.Unfocus();
			};
			lblHidekeyboard.GestureRecognizers.Add(HideKeyboard);

			var layoutImageContent = new StackLayout { Spacing = 8, Padding = new Thickness(0, 5, 0, 0), Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };

			var imgLeft = new Image { Source = "rotate_left.png", HeightRequest = 25, WidthRequest = 25, HorizontalOptions = LayoutOptions.StartAndExpand };
			var imgLefts = new Image { Source = "rotate_left.png", HeightRequest = 25, WidthRequest = 25, HorizontalOptions = LayoutOptions.StartAndExpand };

			var imgAssets = new Image { HeightRequest = MyController.ScreenWidth / 2, WidthRequest = MyController.ScreenWidth / 2, HorizontalOptions = LayoutOptions.FillAndExpand };
			var imgRight = new Image { Source = "rotate_right.png", HeightRequest = 25, WidthRequest = 25, HorizontalOptions = LayoutOptions.EndAndExpand };
			//var indicator = new ActivityIndicator { Color = Xamarin.Forms.Color.Red, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };

			if (ViewModel.Picture != null)
			{
				try
				{
					//imgAssets.SetBinding(Image.SourceProperty, new Binding("Picture", BindingMode.TwoWay));

					var imageOfAssets = DependencyService.Get<IPicture>().GetPictureFromDiskTemp(ViewModel.Device.device_idx, ViewModel.CountAsset);

#if __ANDROID__
				imgAssets.Source = ImageSource.FromStream(() => new MemoryStream(imageOfAssets));
#endif


#if __IOS__
					imgAssets.SetBinding(Image.SourceProperty, new Binding("Picture", BindingMode.TwoWay));
#endif

					//imgAssets.Source = "troubleShooting.png";

					layoutImageContent.Children.Add(imgLeft);
					//layoutImageContent.Children.Add(imgLefts);
					layoutImageContent.Children.Add(imgAssets);
					layoutImageContent.Children.Add(imgRight);


					TapGestureRecognizer Tapleft = new TapGestureRecognizer();
					Tapleft.Tapped += (object sender, EventArgs e) =>
				   {
					   try
					   {
						   IsRotate = true;
						   //if (imgAsset.Rotation >= 0)
						   //{
						   imgAssets.Rotation -= 90;
						   ViewModel.RotationAngle -= 90;
					   }
					   catch { }
				   };
					imgLeft.GestureRecognizers.Add(Tapleft);


					TapGestureRecognizer TapRight = new TapGestureRecognizer();
					TapRight.Tapped += (object sender, EventArgs e) =>
					   {
						   IsRotate = true;
						   //if (imgAsset.Rotation <= 0)
						   //{
						   imgAssets.Rotation += 90;
						   ViewModel.RotationAngle += 90;
						   //}
					   };
					imgRight.GestureRecognizers.Add(TapRight);


					var layoutButton = new StackLayout { Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.CenterAndExpand };
					var btnSave = new Button { Text = "   Save   ", WidthRequest = MyController.ScreenWidth / 2 - 40, BackgroundColor = Color.Red, TextColor = Color.White };
					var btnCancel = new Button { Text = "Cancel", WidthRequest = MyController.ScreenWidth / 2 - 40, BackgroundColor = Color.FromRgb(123, 123, 123), TextColor = Color.White };

					layoutButton.Children.Add(btnSave);
					layoutButton.Children.Add(btnCancel);
					btnCancel.Clicked += (sender, e) =>
					{

						Navigation.PopAsync();
					};

					btnSave.Clicked += async (object sender, EventArgs e) =>
						{
							var networkConnection = DependencyService.Get<INetworkConnection>();
							networkConnection.CheckNetworkConnection();
							var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
							if (networkStatus != "Connected")
							{
								UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
								return;
							}

							string address = "Are you sure you want to update this Asset?";
							var answer = await DisplayAlert("Update Asset", address, "Yes", "No");
							if (answer == true)
							{
								using (UserDialogs.Instance.Loading("Uploading Asset..."))
								{
									//await Task.Delay(1000);

									if (Asset.Deviceimage == null)
										Asset.Deviceimage = DependencyService.Get<IPicture>().GetPictureFromDisk(ViewModel.Device.device_idx, ViewModel.CountAsset);


									Asset.Device_id = ViewModel.Device.device_idx;
									Asset.Deviceasset_idx = 0;
									Asset.geo_coords = " ";
									if (IsRotate)
									{
										if (ViewModel.RotationAngle != 0)
											Asset.RotationAngle = (ViewModel.RotationAngle / 90) + 1;
									}
									else
									{
										if (ViewModel.FromCameraCap)
										{
											Asset.RotationAngle = 1;
										}
										else
										{
											if (ViewModel.RotationAngle != 0)
												Asset.RotationAngle = (ViewModel.RotationAngle / 90);
										}

									}

									//Asset.RotationAngle = AssetViewModel.RotationAngle / 90;

									Asset.OwnerUserID = Settings.UserID;
									Asset.friendly_name = ViewModel.Device.FriendlyName;
									Asset.description = EditorDesc.Text;
									Asset.strExpireDate = DateExpiryDate.Date.ToString("dd-MMM-yyyy HH:mm:ss");
									Asset.strCreatedDate = System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss");
									Asset.strModifyDate = System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss");
									Asset.strPurchaseDate = DatePickerPurchageDate.Date.ToString("dd-MMM-yyyy HH:mm:ss");

									IsRotate = false;

									var saveimg = await ApiService.Instance.SaveAsset(Asset);

								}
								await UserDialogs.Instance.AlertAsync("Asset Updated Successfully", "Information", "OK");

								System.GC.Collect();
								await Navigation.PopAsync(true);
							}
						};

					var stacklayoutMain = new StackLayout { Spacing = 8, Padding = 10, VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };
					stacklayoutMain.Children.Add(layoutMainDate);
					stacklayoutMain.Children.Add(layoutDescription);
					stacklayoutMain.Children.Add(layoutImageContent);
					stacklayoutMain.Children.Add(layoutButton);

					var scrl = new ScrollView { };
					scrl.Content = stacklayoutMain;

					Content = scrl;
				}
				catch{
					
				}
			}
		}
		protected override bool OnBackButtonPressed()
		{
			try
			{
				System.GC.Collect();
				MyController.fromAssetsToGallery = true;

			}
			catch { }
			return base.OnBackButtonPressed();
		}
	}
	

}


