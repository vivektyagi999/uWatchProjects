﻿using System;
using System.Threading.Tasks;
using Acr.UserDialogs;
using FFImageLoading.Forms;
using uWatch.Controls;
using UwatchPCL;
using UwatchPCL.Model;
using Xamarin.Forms;

namespace uWatch
{
	public class NewAssetsDetailPage : ContentPage
	{
		public AssetDetailsViewModel ViewModel { get; set; }
		public DeviceAssetsModel DeviceAsset;
		public DeviceAssetsModel TempDeviceAsset;
		public NewAssetsDetailPage(int position, DeviceAssetsModel selectedImageModel, AssetDetailsViewModel viewmodel)
		{
			try
			{
				DeviceAsset = selectedImageModel;
				TempDeviceAsset = selectedImageModel;
				Title = "Asset Details";
				this.ViewModel = viewmodel;
				BindingContext = ViewModel.DeviceAsset;
				SetLayout();
			}
			catch { }

		}
		private async void SetLayout()
		{
			var lblpurchaseDate = new Label { Text = "Purchase Date",FontSize = 18, TextColor = Color.Gray, WidthRequest = MyController.ScreenWidth / 2 - 50, HeightRequest = 40 };
			var DatePickerPurchageDate = new DatePicker { WidthRequest = MyController.ScreenWidth / 2 - 50, HeightRequest = 40 };
			DatePickerPurchageDate.SetBinding(Xamarin.Forms.DatePicker.DateProperty, new Binding("PurchaseDate", BindingMode.TwoWay));
			var layoutPurchage = new StackLayout { HorizontalOptions = LayoutOptions.StartAndExpand, Spacing = 2 };
			layoutPurchage.Children.Add(lblpurchaseDate);
			layoutPurchage.Children.Add(DatePickerPurchageDate);


			var lblExpiryDate = new Label { Text = "Warranty Expiry",FontSize = 18, TextColor = Color.Gray, WidthRequest = MyController.ScreenWidth / 2 - 50, HeightRequest = 40 };
			var DateExpiryDate = new DatePicker { WidthRequest = MyController.ScreenWidth / 2 - 50, HeightRequest = 40 };
			DateExpiryDate.SetBinding(Xamarin.Forms.DatePicker.DateProperty, new Binding("ExpireDate", BindingMode.TwoWay));
			var layoutExpiry = new StackLayout { HorizontalOptions = LayoutOptions.EndAndExpand, Spacing = 2 };
			layoutExpiry.Children.Add(lblExpiryDate);
			layoutExpiry.Children.Add(DateExpiryDate);

			var layoutMainDate = new StackLayout { Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.FillAndExpand };
			layoutMainDate.Children.Add(layoutPurchage);
			layoutMainDate.Children.Add(layoutExpiry);

			var layoutDescription = new StackLayout { Spacing = 2, HeightRequest = 100 };
			var lblDesc = new Label { Text = "Description",FontSize = 18, TextColor = Color.Gray };
			var lblHide = new Label { Text = "Tap me to hide the keyboard", IsVisible = false, FontSize = 16, TextColor = Color.Red, FontAttributes = FontAttributes.Italic };
			var EditorDesc = new ExtendedEditor { HeightRequest = 90 };
			EditorDesc.SetBinding(ExtendedEditor.TextProperty, new Binding("description", BindingMode.TwoWay));
			layoutDescription.Children.Add(lblDesc);

			layoutDescription.Children.Add(lblHide);
			layoutDescription.Children.Add(EditorDesc);

			EditorDesc.Focused += (sender, e) => {
				lblHide.IsVisible = true;

			};
			EditorDesc.Unfocused += (sender, e) =>
			{
				lblHide.IsVisible = false;

			};

			TapGestureRecognizer HideKeyboard = new TapGestureRecognizer();
			HideKeyboard.Tapped += async (object sender, EventArgs e) =>
			{
				EditorDesc.Unfocus();
			};
				lblHide.GestureRecognizers.Add(HideKeyboard);

			var layoutImageContent = new StackLayout { Spacing = 8, Padding = new Thickness(0, 0, 0, 0), Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
			var imgLeft = new Image { Source = "rotate_left.png", HeightRequest = 25, WidthRequest = 25, HorizontalOptions = LayoutOptions.StartAndExpand };
			var imgAssets = new CachedImage { HeightRequest = MyController.ScreenWidth / 2, WidthRequest = MyController.ScreenWidth / 2, HorizontalOptions = LayoutOptions.FillAndExpand };
			var imgRight = new Image { Source = "rotate_right.png", HeightRequest = 25, WidthRequest = 25, HorizontalOptions = LayoutOptions.EndAndExpand };
			var indicator = new ActivityIndicator { Color = Xamarin.Forms.Color.Red, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };

			System.Uri uri;
			System.Uri.TryCreate(ViewModel.DeviceAsset.UploadedFilePath, UriKind.Absolute, out uri);
			Task<ImageSource> result = Task<ImageSource>.Factory.StartNew(() => ImageSource.FromUri(uri));
			imgAssets.Source = await result;

			indicator.SetBinding(ActivityIndicator.IsRunningProperty, "IsLoading");

			var relativelayout = new RelativeLayout { };
			relativelayout.Children.Add(imgAssets,
			 Constraint.RelativeToParent((parent) =>
				{
					return 10;
				}),
				Constraint.RelativeToParent((parent) =>
				{
					return 50;
				}),
				Constraint.RelativeToParent((parent) =>
				{
					return MyController.ScreenWidth - 100;
				}),
				Constraint.RelativeToParent((parent) =>
				{
					return MyController.ScreenWidth - 130;
				}));

			relativelayout.Children.Add(indicator,
				Constraint.RelativeToParent((parent) =>
				{
					return parent.Width / 2;
				}),
				Constraint.RelativeToParent((parent) =>
				{
					return parent.Height / 2;
				}));


			indicator.BindingContext = imgAssets;

			layoutImageContent.Children.Add(imgLeft);
			layoutImageContent.Children.Add(relativelayout); 
			layoutImageContent.Children.Add(imgRight);

			TapGestureRecognizer bigt = new TapGestureRecognizer();
			bigt.Tapped += async (object sender, EventArgs e) =>
			{
				Navigation.PushAsync(new ZoomPage(imgAssets.Source));
				//if (!indicator.IsRunning)
				//{
				//	try
				//	{
				//		var networkConnection = DependencyService.Get<INetworkConnection>();
				//		networkConnection.CheckNetworkConnection();
				//		var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
				//		if (networkStatus != "Connected")
				//		{
				//			UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
				//			return;
				//		}

				//		UserDialogs.Instance.ShowLoading("Loading...");



				//		ContentPage p = new ContentPage();
				//		StackLayout st = new StackLayout { Padding = 10, HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
				//		Xamarin.Forms.RelativeLayout r = new Xamarin.Forms.RelativeLayout();


				//		var i = new CachedImage();
				//		i.Aspect = Aspect.AspectFill;

				//		i.CacheDuration = TimeSpan.FromDays(50);
				//		i.DownsampleHeight = 300;
				//		i.RetryCount = 20;
				//		i.RetryDelay = 5;
				//		i.TransparencyEnabled = false;
				//		//i.LoadingPlaceholder = "comingSoon.png";
				//		//				Images.VerticalOptions = LayoutOptions.CenterAndExpand;

				//		i.HorizontalOptions = LayoutOptions.FillAndExpand;
				//		i.VerticalOptions = LayoutOptions.FillAndExpand;

				//		//CachedImage i = new CachedImage { Aspect = Aspect.AspectFit, LoadingPlaceholder = ImageSource.FromFile("comingSoonImage.png"), ErrorPlaceholder = ImageSource.FromFile("noimage.gif"),HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };

				//		i.Source = imgAssets.Source;


				//		i.Aspect = Aspect.AspectFit;
				//		st.Children.Add(i);


				//		p.Title = "Asset Image";


				//		p.Content = st;
				//		await Navigation.PushAsync(p);

				//		await Task.Delay(500);

				//		UserDialogs.Instance.HideLoading();
				//	}
				//	catch
				//	{
				//	}
				//}
			};
		
			indicator.GestureRecognizers.Add(bigt);
			imgAssets.GestureRecognizers.Add(bigt);

			TapGestureRecognizer Tapleft = new TapGestureRecognizer();
			Tapleft.Tapped += (object sender, EventArgs e) =>
		   {
			   //if (imgAsset.Rotation >= 0)
			   //{
			   imgAssets.Rotation -= 90;
			   ViewModel.DeviceAsset.RotationAngle -= 90;
			   //}
		   };
			imgLeft.GestureRecognizers.Add(Tapleft);


			TapGestureRecognizer TapRight = new TapGestureRecognizer();
			TapRight.Tapped += (object sender, EventArgs e) =>
			   {
				   //if (imgAsset.Rotation <= 0)
				   //{
				   imgAssets.Rotation += 90;
				   ViewModel.DeviceAsset.RotationAngle += 90;
				   //}
			   };
			imgRight.GestureRecognizers.Add(TapRight);


			var layoutButton = new StackLayout { Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.EndAndExpand };
			var btnSave = new Button { Text = "Save", WidthRequest = MyController.ScreenWidth / 3-10, BackgroundColor = Color.Red, TextColor = Color.White };
			var btnDelete = new Button { Text = "Delete", WidthRequest = MyController.ScreenWidth /3-10, BackgroundColor = Color.Red, TextColor = Color.White };
			var btnCancel = new Button { Text = "Cancel", WidthRequest = MyController.ScreenWidth /3-10, BackgroundColor = Color.FromRgb(123,123,123), TextColor = Color.White };

			layoutButton.Children.Add(btnSave);
			layoutButton.Children.Add(btnDelete);
			layoutButton.Children.Add(btnCancel);
			btnCancel.Clicked += (sender, e) => {

				Navigation.PopAsync();
			};

			btnSave.Clicked += async (object sender, EventArgs e) =>
				{
					var networkConnection = DependencyService.Get<INetworkConnection>();
					networkConnection.CheckNetworkConnection();
					var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
					if (networkStatus != "Connected")
					{
						UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
						return;
					}

					//string address = "Are you sure you want to update this Asset?";
					//var answer = await DisplayAlert("Update Asset", address, "Yes", "No");
					//if (answer == true)
					//{
						//if (btnEdit.Text == "Edit")
						//{
						DatePickerPurchageDate.IsEnabled = true;
						DateExpiryDate.IsEnabled = true;
						EditorDesc.IsEnabled = true;
						//	btnEdit.Text = "Save";
						//}
						//else
						//{
						UserDialogs.Instance.ShowLoading("Updating Asset...");

						ViewModel.DeviceAsset.RotationAngle = ViewModel.DeviceAsset.RotationAngle / 90;
						ViewModel.DeviceAsset.Device_id = ViewModel.DeviceAsset.Device_id;
						ViewModel.DeviceAsset.Deviceimage = ViewModel.DeviceAsset.Deviceimage;
						ViewModel.DeviceAsset.Deviceasset_idx = ViewModel.DeviceAsset.Deviceasset_idx;
						ViewModel.DeviceAsset.geo_coords = ViewModel.DeviceAsset.geo_coords;
						ViewModel.DeviceAsset.friendly_name = ViewModel.DeviceAsset.friendly_name;
						ViewModel.DeviceAsset.description = EditorDesc.Text;
						ViewModel.DeviceAsset.strExpireDate = DateExpiryDate.Date.ToString("dd-MMM-yyyy");
						ViewModel.DeviceAsset.strCreatedDate = System.DateTime.Now.ToString("dd-MMM-yyyy");
						ViewModel.DeviceAsset.strModifyDate = System.DateTime.Now.ToString("dd-MMM-yyyy");
						ViewModel.DeviceAsset.strPurchaseDate = DatePickerPurchageDate.Date.ToString("dd-MMM-yyyy");

						var saveimg = await ApiService.Instance.SaveAsset(ViewModel.DeviceAsset);

						UserDialogs.Instance.HideLoading();
						await UserDialogs.Instance.AlertAsync("Asset Updated Successfully", "Information", "OK");
						System.GC.Collect();
						MyController.fromAssetsToGallery = true;
						await Navigation.PopAsync(true);
					//}
				};
			btnDelete.Clicked += async (object sender, EventArgs e) =>
{

	var networkConnection = DependencyService.Get<INetworkConnection>();
	networkConnection.CheckNetworkConnection();
	var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
	if (networkStatus != "Connected")
	{
		UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
		return;
	}

	string address = "Are you sure you want to delete this Asset?";
	var answer = await DisplayAlert("Delete Asset", address, "Yes", "No");
	if (answer == true)
	{
		UserDialogs.Instance.ShowLoading("Deleting Asset...");
		//await Task.Delay(1000);

		var resu = await ApiService.Instance.DeleteAsset(ViewModel.DeviceAsset);
		UserDialogs.Instance.HideLoading();

		await UserDialogs.Instance.AlertAsync("Asset Deleted Successfully", "Information", "OK");
		MyController.fromAssetsToGallery = true;
		await Navigation.PopAsync(true);
	}
};


			var stacklayoutMain = new StackLayout { Spacing = 8, Padding = 8, VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };
			stacklayoutMain.Children.Add(layoutMainDate);
			stacklayoutMain.Children.Add(layoutDescription);
			stacklayoutMain.Children.Add(layoutImageContent);
			stacklayoutMain.Children.Add(layoutButton);


			TapGestureRecognizer bigts = new TapGestureRecognizer();
			bigts.Tapped += async (object sender, EventArgs e) =>
			{
				EditorDesc.Unfocus();
			};
			stacklayoutMain.GestureRecognizers.Add(bigts);

			var scrl = new ScrollView { };
			scrl.Content = stacklayoutMain;

			Content = scrl;
		}
		protected override bool OnBackButtonPressed()
		{
			try
			{
				System.GC.Collect();
				MyController.fromAssetsToGallery = true;

			}
			catch { }
			return base.OnBackButtonPressed();
		}
	}

}


