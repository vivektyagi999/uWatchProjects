﻿using System;
using System.Collections.Generic;
using UwatchPCL;
using Xamarin.Forms;

namespace uWatch
{
	public partial class AuthenticationPage : ContentPage
	{
		Xamarin.Forms.RelativeLayout relativeLayout;
		Xamarin.Forms.ScrollView scrollview;
		double w = MyController.VirtualWidth;
		double h = MyController.VirtualHeight;

		public AuthenticationPage()
		{
			InitializeComponent();

			//SetLayout();
		}
	}
}

