﻿using uwatch.ViewModels;
using Xamarin.Forms;

namespace uWatch
{
	public partial class ImageGallery : ContentPage
	{
		public ImageGallery()
		{
			InitializeComponent();
		}

		public ImageGallery(GalleryViewModel gv)
		{
			InitializeComponent();
			BindingContext = gv;
		}

		protected override void OnAppearing()
		{
			base.OnAppearing();
		}
	}
}

