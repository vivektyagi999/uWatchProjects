﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Acr.UserDialogs;
using UwatchPCL;
using Xamarin.Forms;
using Xamarin.Forms.Maps;
using UwatchPCL.Helpers;

#if __ANDROID__
using uWatch.Droid;
using Android.App;
using Android.Widget;
#endif

namespace uWatch
{
	public partial class AlertListPage : ContentPage
	{
		bool IsMap;
		Xamarin.Forms.RelativeLayout relativelayout;
		Xamarin.Forms.ScrollView scrollview;
		private int DeviceId;
		double w = MyController.VirtualWidth;
		double h = MyController.VirtualHeight;

		public static int ExistingAlertId { get; set; }

		private InfiniteListView listView;

		private DataTemplate Cell { get; set; }
		private AlertsListViewModel ViewModel { get; set; }
		Geocoder geoCoder;

		public AlertListPage()
		{
			try
			{
				InitializeComponent();
			}
			catch { }
		}

		public AlertListPage(int deviceid, AlertsListViewModel viewmodel)
		{
			try
			{
				this.DeviceId = deviceid;
				ViewModel = viewmodel;

				InitializeComponent();

				BindingContext = ViewModel;
				SetLayout();
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}

		protected async override void OnAppearing()
		{
			base.OnAppearing();
			try
			{
				if (MyController.fromAssetsToGallery)
				{
					await ViewModel.LoadAlertInExistingList(ExistingAlertId);
				}
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}

		public async void SetLayout()
		{
			try
			{
				if (Settings.RoleID == 3)
				{
					Title = "Escalted Alert List";
				}
				else
				{
					Title = "Alert List";
				}
				relativelayout = new Xamarin.Forms.RelativeLayout();
				scrollview = new Xamarin.Forms.ScrollView();
				AddLayout();
				scrollview.Content = relativelayout;
				Content = relativelayout;
			}
			catch { }
		}

		private async void AddLayout()
		{
			try
			{
				double newx40 = MyUiUtils.getPercentual(w, 40);
				double newy30 = MyUiUtils.getPercentual(h, 30);

				listView = new InfiniteListView();
				listView.BackgroundColor = Color.FromRgb(247, 247, 247);
				listView.BindingContext = ViewModel;
				//listView.Items = ViewModel.AlertList;
				//Binding myBinding = new Binding("AlertList");
				//myBinding.Source = ViewModel;
				//myBinding.Path = "AlertList";
				//myBinding.Mode = BindingMode.TwoWay;
				//listView.SetBinding(Xamarin.Forms.ListView.ItemsSourceProperty, myBinding);


				listView.SetBinding(Xamarin.Forms.ListView.ItemsSourceProperty, new Binding("AlertList", BindingMode.TwoWay));
				listView.LoadMoreCommand = ViewModel.LoadCharactersCommand;

				//listView.ItemClickCommand = ViewModel.LoadAlertCommand;
				//listView.SetBinding(Xamarin.Forms.ListView.SelectedItemProperty, new Binding("Alert", BindingMode.TwoWay));

				Cell = new DataTemplate(typeof(AlertListCell));
				listView.ItemTemplate = Cell;

				listView.ItemSelected += async (sender, e) =>
				{
					try
					{
						if (e.SelectedItem != null)
						{
							var networkConnection = DependencyService.Get<INetworkConnection>();
							networkConnection.CheckNetworkConnection();
							var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
							if (networkStatus != "Connected")
							{

								UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
								//listView.SelectedItem = null;
								return;
							}
							UserDialogs.Instance.ShowLoading("Loading...");
							//await Task.Delay(5);

							MyController.fromAssetsToGallery = false;


							var alert = e.SelectedItem as AlertsEsclatedToAgentViewModel;
							ExistingAlertId = alert.alertlog_idx;
							AlertsEsclatedToAgentViewModel req = new AlertsEsclatedToAgentViewModel();
							req.alertlog_idx = ExistingAlertId;
							var EscaltingAlert = await ApiService.Instance.GetAlert(req);

							listView.SelectedItem = null;

							await Task.Delay(250);
							if (Settings.RoleID == 3)
							{
								Navigation.PushAsync(new AlertDetailsForAgent(EscaltingAlert));
							}
							else {
								await Navigation.PushAsync(new AlertDetail(EscaltingAlert));
							}
							await Task.Delay(750);
							UserDialogs.Instance.HideLoading();
						}
					}
					catch {
						UserDialogs.Instance.HideLoading();
					}
				};



				var customMap = new AlertsMap
				{
					MapType = MapType.Street,
					WidthRequest = w - 40,
					HeightRequest = 500
				};

				// to get the alert last location of all devices



				//	var Itemsss = await ApiService.Instance.GetDeviceList(reqs);
				if (Settings.RoleID == 3)
				{
					foreach (var alert in ViewModel.AlertList)
					{
						if ((Convert.ToDouble(alert.lat) > 0) && Convert.ToDouble(alert.lang) > 0)
						{
							var pos = new Position(Convert.ToDouble(alert.lat), Convert.ToDouble(alert.lang));
							var pin = new Pin
							{
								Type = PinType.Place,
								Position = pos,
							};

							//pin.Type = PinType.Place;
							//pin.Position = pos;
							//var possibleAddresses = geoCoder.GetAddressesForPositionAsync(pos).Result;
							//foreach (var address in possibleAddresses)
							//{
							//pin.Address += address + "\n";
							pin.Label = pos.Latitude.ToString() + "," + pos.Longitude.ToString();
							customMap.Pins.Add(pin);
							//}
							//customMap.RouteCoordinates.Add(pos);
							//customMap.Pins.Add(customMap.MapPins);

							customMap.MoveToRegion(MapSpan.FromCenterAndRadius(pos, Distance.FromMiles(1.0)));
							IsMap = true;
						}
						else {
							IsMap = false;
						}
					}
				}
				else
				{
					foreach (var alert in ViewModel.AlertLastLocStatic)
					{
						if ((Convert.ToDouble(alert.lat) > 0) && Convert.ToDouble(alert.lang) > 0)
						{
							var pos = new Position(Convert.ToDouble(alert.lat), Convert.ToDouble(alert.lang));
							var pin = new Pin
							{
								Type = PinType.Place,
								Position = pos,
							};
							//var possibleAddresses = geoCoder.GetAddressesForPositionAsync(pos).Result;
							//foreach (var address in possibleAddresses)
							//{
							//pin.Address += address + "\n";
							pin.Label = pos.Latitude.ToString() + "," + pos.Longitude.ToString();
							//}
							customMap.Pins.Add(pin);
							customMap.MoveToRegion(MapSpan.FromCenterAndRadius(pos, Distance.FromMiles(1.0)));
							IsMap = true;
						}
						else {
							IsMap = false;
					}
				 }
				}


				if (ViewModel.AlertList.Count > 0)
				{
					if(customMap.Pins.Count>0)
					{

						MyUILibrary.AddListView(relativelayout, listView, 0, 0, w, h / 2 + 70, listView.SeparatorColor, 100);
						if (Device.Idiom == TargetIdiom.Phone)
						{
							MyUILibrary.AddMap(relativelayout, customMap, 0, (h / 2) + 70, w, (h / 2 + 20) - 80);
						}
						else if (Device.Idiom == TargetIdiom.Tablet)
						{
							MyUILibrary.AddMap(relativelayout, customMap, 0, (h / 2 - 30) + 10, w, (h / 2 + 20));
						}
					}
					else { 
						MyUILibrary.AddListView(relativelayout, listView, 0, 0, w, h, listView.SeparatorColor, 100);

					}
				}
				else
				{
					var lblerror = MyUILibrary.AddLabel(relativelayout, "No Alerts to display", (w - newx40) / 2, newy30, newx40, 50, listView.SeparatorColor, 18);
				}

			}
			catch(System.Exception ex) 
			{
				await DisplayAlert("Error", ex.StackTrace, "Cancel");
			}
		}

	}

}

