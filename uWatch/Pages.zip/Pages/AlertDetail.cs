﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Acr.UserDialogs;
using FFImageLoading.Forms;
using UwatchPCL;
using UwatchPCL.Helpers;
using Xamarin.Forms;
using Xamarin.Forms.Maps;


#if __ANDROID__
using Android.App;
using Android.Widget;
using uWatch.Droid;
using Android.Gms.Gcm;

#endif


namespace uWatch
{
	public partial class AlertDetail : ContentPage
	{
		AlertsEsclatedToAgentViewModel Alert;
		Xamarin.Forms.RelativeLayout relativeLayout;
		Xamarin.Forms.ScrollView scrollview;
		public Label lblCountdownValue;
		//public IUserDialogs userdialogs;
		double w = MyController.VirtualWidth;
		double h = MyController.VirtualHeight;
		bool noimage = false;
		bool noMap = false;
		Geocoder geoCoder;

		AlertsEsclatedToAgentViewModel SendToActionPage;

		int GlobleDevceId;

		public AlertDetailsViewModel ViewModel { get; set; }

		public AlertDetail(string str = "")
		{
			try
			{
				//userdialogs = UserDialogs.Instance;

				var testingLbl = new Label { Text = "Loading..", VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.CenterAndExpand };
				Content = testingLbl;


				if (!string.IsNullOrEmpty(str))
				{
					var lblMsg = new Label { Text = str, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 15 };
					Content = lblMsg;
				}
				else {

					geoCoder = new Geocoder();
					var alertid = MyController.AlertId;
					AlertsEsclatedToAgentViewModel req = new AlertsEsclatedToAgentViewModel();
					req.alertlog_idx = alertid == "" ? 0 : Convert.ToInt32(alertid);
					var alert = ApiService.Instance.GetAlert(req).Result;
					this.Alert = alert;
					ViewModel = new AlertDetailsViewModel(this.Alert);
					Timer();
					BindingContext = ViewModel.device;

					SetLayout();
				}
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}
		public AlertDetail(AlertsEsclatedToAgentViewModel alert)
		{
			try
			{
				var testingLbl = new Label { Text = "Loading..", VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.CenterAndExpand };
				Content = testingLbl;



				SendToActionPage = alert;
				this.Alert = alert;
				geoCoder = new Geocoder();
				ViewModel = new AlertDetailsViewModel(this.Alert);
				Timer();
				BindingContext = ViewModel.device;
				SetLayout();
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}

		protected async override void OnAppearing()
		{
			base.OnAppearing();
		}

		protected override void OnDisappearing()
		{
			try
			{
				System.GC.Collect();
				base.OnDisappearing();
			}
			catch { }
		}

		private async void SetLayout()
		{
			try
			{
#if __ANDROID__

			//var activity = Forms.Context as Activity;
			//var tt = activity.FindViewById<TextView>(Resource.Id.toolbar_title);
			//tt.Text = "Alerts Details";
#endif
#if __IOS__
				Title = "Alert Details";
#endif
				Title = "Alert Details";
				//relativeLayout = new Xamarin.Forms.RelativeLayout();
				AddLayout();
				//scrollview = new Xamarin.Forms.ScrollView();
				//scrollview.Content = relativeLayout;
				//Content = scrollview;
			}
			catch { }
		}
		private  async System.Threading.Tasks.Task AddLayout()
		{

			try
			{

				double position = 0;
				double newx20 = MyUiUtils.getPercentual(w, 20);
				double newx40 = MyUiUtils.getPercentual(w, 40);
				double newx60 = MyUiUtils.getPercentual(w, 60);
				double newx80 = MyUiUtils.getPercentual(w, 80);

				//var imgTitle = MyUILibrary.AddImage(relativeLayout, "alert_bg.png", 0, position, w, 100, Aspect.AspectFit);
				//var imgAlertType = MyUILibrary.AddImage(relativeLayout, "Icon.png", 50, position + 20 + 2, 50, 50, Aspect.AspectFit);

				//imgAlertType.HorizontalOptions = LayoutOptions.Center;
				//if (ViewModel != null)
				//	imgAlertType.Source = await MyController.GetAlertTypelImage(ViewModel.device.alert_type);
				//var lblAlertType = MyUILibrary.AddLabel(relativeLayout, "", ((w - newx80) / 2), position + 20 - 3, w, 50, Color.Red, 22);
				//lblAlertType.FontAttributes = FontAttributes.Bold;
				//if (ViewModel != null)
				//	lblAlertType.Text = " !!     " + MyController.GetAlertTypeName(ViewModel.device.alert_type).ToUpper() + " !! ";


				var img1 = new Image { Source= "gray_line.png",Aspect=Aspect.Fill,WidthRequest=App.ScreenWidth};
				var img2 = new Image { Source = "gray_line.png", Aspect = Aspect.Fill,WidthRequest = App.ScreenWidth };
				var img3 = new Image { Source = "gray_line.png", Aspect = Aspect.Fill,WidthRequest = App.ScreenWidth };
				var box = new BoxView { HeightRequest = 20 };

				StackLayout layout = new StackLayout {VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };
				StackLayout mainstack = new StackLayout { VerticalOptions = LayoutOptions.StartAndExpand };
				mainstack.Padding = new Thickness(12, 0, 12, 10);

				StackLayout alertimagestack = new StackLayout { VerticalOptions = LayoutOptions.Start, HorizontalOptions = LayoutOptions.Start  };
				StackLayout mapstack = new StackLayout { VerticalOptions = LayoutOptions.EndAndExpand, HorizontalOptions = LayoutOptions.EndAndExpand  };
				StackLayout mapandimagestack = new StackLayout { Orientation = StackOrientation.Horizontal, Spacing = 2, HorizontalOptions = LayoutOptions.FillAndExpand };
				mapandimagestack.Children.Add(alertimagestack);
				mapandimagestack.Children.Add(mapstack);

				StackLayout awaketimestack = new StackLayout { Orientation = StackOrientation.Horizontal,HorizontalOptions = LayoutOptions.Start, VerticalOptions = LayoutOptions.EndAndExpand};

				StackLayout countdownstack = new StackLayout { Orientation = StackOrientation.Horizontal,HorizontalOptions = LayoutOptions.EndAndExpand, VerticalOptions = LayoutOptions.EndAndExpand };

				StackLayout timestack = new StackLayout { Orientation = StackOrientation.Horizontal };
				timestack.Children.Add(awaketimestack);
				timestack.Children.Add(countdownstack);

				StackLayout descdetail = new StackLayout { };

				StackLayout buttonstack = new StackLayout { Orientation = StackOrientation.Horizontal, VerticalOptions = LayoutOptions.EndAndExpand, Padding = new Thickness(12, 0, 12, 10) };

				StackLayout Templayout = new StackLayout {HorizontalOptions=LayoutOptions.StartAndExpand };
				StackLayout signallayout = new StackLayout {HorizontalOptions = LayoutOptions.CenterAndExpand };
				StackLayout batterylayout = new StackLayout {HorizontalOptions = LayoutOptions.EndAndExpand };

				StackLayout TSBlayout = new StackLayout { Orientation = StackOrientation.Horizontal};
				TSBlayout.Children.Add(Templayout);
				TSBlayout.Children.Add(signallayout);
				TSBlayout.Children.Add(batterylayout);



				StackLayout headstack = new StackLayout() { BackgroundColor = Color.FromRgb(244, 244, 244),Padding = new Thickness(0, 10, 0, 15) };
				headstack.Orientation = StackOrientation.Horizontal;
				headstack.HorizontalOptions = LayoutOptions.FillAndExpand;
				headstack.VerticalOptions = LayoutOptions.FillAndExpand;

				StackLayout Substack = new StackLayout() { };
				Substack.Orientation = StackOrientation.Horizontal;
				Substack.HorizontalOptions = LayoutOptions.CenterAndExpand;
				Substack.VerticalOptions = LayoutOptions.CenterAndExpand;

				var lblAlertText1 = new Label { Text = "!!", FontSize = 19, FontAttributes = FontAttributes.Bold, TextColor = Color.Red, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };
				var imgAlerts = new Image { HeightRequest = 20, WidthRequest = 20, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };
				if (ViewModel != null)
				{
					if (ViewModel.device != null)
						imgAlerts.Source = await MyController.GetAlertTypelImage(ViewModel.device.alert_type);
				}

				var lblAlertText = new Label { FontSize = 19, FontAttributes = FontAttributes.Bold, TextColor = Color.Red, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };
				if (ViewModel.device != null)
					lblAlertText.Text = MyController.GetAlertTypeName(ViewModel.device.alert_type).ToUpper() + " !! ";

				//headstack.Children.Add(imgTitle);
				Substack.Children.Add(lblAlertText1);
				Substack.Children.Add(imgAlerts);
				Substack.Children.Add(lblAlertText);

				headstack.Children.Add(Substack);

				//MyUILibrary.AddLayout(relativeLayout, headstack, 0, position, w, 50);



				//position += 75;
				//var lblFirndlyName = MyUILibrary.AddLabel(relativeLayout, "''Shed at back of garrage.......''", 10, position, w, 50, Color.Gray, 19);
				var lblFirndlyName = new Label();
				lblFirndlyName.SetBinding(Label.TextProperty, new Binding("FriendlyName", BindingMode.Default));
				lblFirndlyName.TextColor = Color.Gray;
				lblFirndlyName.HorizontalTextAlignment = TextAlignment.Start;
				lblFirndlyName.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblFirndlyName.VerticalOptions = LayoutOptions.StartAndExpand;


				//position += 25;
				//var lblAlertDateTime = MyUILibrary.AddLabel(relativeLayout, "Tuesday 15th May 03:00am", 10, position, w, 50, Color.Gray, 19);
				var lblAlertDateTime = new Label();
				var alertdate = ViewModel.device.DeviceDate.ToString("dddd dd-MMM hh:mm tt");
				lblAlertDateTime.SetBinding(Label.TextProperty, new Binding("DeviceDate", BindingMode.Default, stringFormat: alertdate));
				lblAlertDateTime.HorizontalTextAlignment = TextAlignment.Start;
				lblAlertDateTime.TextColor = Color.Gray;
				lblAlertDateTime.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblAlertDateTime.VerticalOptions = LayoutOptions.StartAndExpand;

				//position += 30;
				//var imgLine = MyUILibrary.AddImage(relativeLayout, "gray_line.png", 0, position, w, 5, Aspect.AspectFit);
				descdetail.Children.Add(lblFirndlyName);
				descdetail.Children.Add(lblAlertDateTime);
				//position += 10;
				//var lblTemp = MyUILibrary.AddLabel(relativeLayout, "Temp.", (w - newx80) / 2, position, newx80, 60, Color.Gray, 18);
				var lblTemp = new Label();
				lblTemp.Text = "Temp.";
				lblTemp.FontSize = 18;
				lblTemp.TextColor = Color.Gray;
				lblTemp.VerticalOptions = LayoutOptions.CenterAndExpand;

				//var lblSignal = MyUILibrary.AddLabel(relativeLayout, "Signal", (w - newx80) / 2 + 120, position, newx80, 60, Color.Gray, 18);
				var lblSignal = new Label();
				lblSignal.Text = "Signal";
				lblSignal.FontSize = 18;
				lblSignal.TextColor = Color.Gray;
				lblSignal.VerticalOptions = LayoutOptions.CenterAndExpand;

				//var lblBattery = MyUILibrary.AddLabel(relativeLayout, "Battery", (w - newx80) / 2 + 240, position, newx80, 60, Color.Gray, 18);
				var lblBattery = new Label();
				lblBattery.Text = "Battery";
				lblBattery.FontSize = 18;
				lblBattery.TextColor = Color.Gray;
				lblBattery.VerticalOptions = LayoutOptions.CenterAndExpand;

				//position += 15
				//var imgTemp = MyUILibrary.AddImage(relativeLayout, "Icon.png", (w - newx80) / 2, position + 10, 75, 50, Aspect.AspectFit);
				var imgTemp = new Image {Source="Icon.png",Aspect= Aspect.AspectFit,VerticalOptions = LayoutOptions.CenterAndExpand,HeightRequest=50,WidthRequest=50};
				imgTemp.SetBinding(Image.SourceProperty, new Binding("TemperatureImage", BindingMode.Default));

				//var imgSignal = MyUILibrary.AddImage(relativeLayout, "Icon.png", (w - newx80) / 2 + 120 - 10, position, 75, 75, Aspect.AspectFit);
				var imgSignal = new Image {Source = "Icon.png", Aspect = Aspect.AspectFit,VerticalOptions = LayoutOptions.CenterAndExpand , HeightRequest = 50, WidthRequest = 50 };
				imgSignal.SetBinding(Image.SourceProperty, new Binding("SignalImage", BindingMode.Default));

				//var imgBattery = MyUILibrary.AddImage(relativeLayout, "Icon.png", (w - newx80) / 2 + 240, position + 10, 75, 75, Aspect.AspectFit);
				var imgBattery = new Image {Source = "Icon.png", Aspect = Aspect.AspectFit ,VerticalOptions = LayoutOptions.CenterAndExpand, HeightRequest = 50, WidthRequest = 50 };
				imgBattery.SetBinding(Image.SourceProperty, new Binding("BatteryImage", BindingMode.Default));

				//position += 60;
				//var lblTempValue = MyUILibrary.AddLabel(relativeLayout, "Temp.", (w - newx80) / 2 + 10, position, newx80, 60, Color.Gray, 18);
				var lblTempValue = new Label { VerticalOptions = LayoutOptions.Center,HorizontalOptions=LayoutOptions.Center};
				lblTempValue.SetBinding(Label.TextProperty, new Binding("DegC", BindingMode.Default, stringFormat: "{0}.C"));

				//var lblSignalValue = MyUILibrary.AddLabel(relativeLayout, "Signal", (w - newx80) / 2 + 120 + 10, position, newx80, 60, Color.Gray, 18);
				var lblSignalValue = new Label{ VerticalOptions = LayoutOptions.Start, HorizontalOptions = LayoutOptions.Center};
				lblSignalValue.SetBinding(Label.TextProperty, new Binding("Signal", BindingMode.Default, stringFormat: "{0}%"));

				//var lblBatteryValue = MyUILibrary.AddLabel(relativeLayout, "Battery", (w - newx80) / 2 + 240 + 10, position, newx80, 60, Color.Gray, 18);
				var lblBatteryValue = new Label {VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Center };
				lblBatteryValue.SetBinding(Label.TextProperty, new Binding("Battery", BindingMode.Default, stringFormat: "{0}%"));

				Templayout.Children.Add(lblTemp);
				Templayout.Children.Add(imgTemp);
				Templayout.Children.Add(lblTempValue);

				signallayout.Children.Add(lblSignal);
				signallayout.Children.Add(imgSignal);
				signallayout.Children.Add(lblSignalValue);


				batterylayout.Children.Add(lblBattery);
				batterylayout.Children.Add(imgBattery);
				batterylayout.Children.Add(lblBatteryValue);


				//position += 30;
				var imgAlert = new CachedImage()
				{
					
					CacheDuration = TimeSpan.FromDays(30),
					DownsampleToViewSize = true,
					RetryCount = 0,
					RetryDelay = 250,
					Aspect = Aspect.Fill,
					TransparencyEnabled = false,
					LoadingPlaceholder = ImageSource.FromFile("noimage.gif"),
					ErrorPlaceholder = ImageSource.FromFile("noimage.gif"),
				};

				if (Device.Idiom == TargetIdiom.Phone)
				{
					imgAlert.WidthRequest = w / 2 - 50;
					imgAlert.HeightRequest = w / 2;
				}
				else
				{
					if (Device.Idiom == TargetIdiom.Tablet)
					{
						imgAlert.WidthRequest = App.ScreenWidth / 2-10 ;
						imgAlert.HeightRequest = App.ScreenWidth / 2 + App.ScreenWidth / 4;
					}
				}
				//imgAlert = MyUILibrary.AddCachedImage(relativeLayout, imgAlert, 20, position, 150, 150, Aspect.AspectFit);
				alertimagestack.Children.Add(imgAlert);
				if (ViewModel != null)
				{
					if (ViewModel.AlertImage != null)
					{
						if (ViewModel.AlertImage.Image != null)
						{
							imgAlert.Source = BytesArraytoImage(ViewModel.AlertImage.Image).Source as StreamImageSource;
						}
						else
						{
							noimage = true;
							if(ViewModel.image_id == 1)
                             {
								//image available
								imgAlert.Source = BytesArraytoImage(ViewModel.AlertImage.Image).Source as StreamImageSource;

							}
							else
							{
								//image not available
								if (ViewModel.Camera_Enable == true)
								{
									if (ViewModel.alert_Type == 0 || ViewModel.alert_Type == 6 || ViewModel.alert_Type == 7)
									{
										//show  Image not required image
										imgAlert.Source = "ImageNotRequired.jpg";

									}
									else
									{
										// fail
										imgAlert.Source = "CameraFail.jpg";

									}

									//show camera fail image
								}
								else {
									//show camera disable image
									imgAlert.Source = "CameraDisable.jpg";
								}
							}
							//imgAlert.Source = ImageSource.FromFile("noimage.gif");
						}
					}
				}
				//imgAlert.SetBinding(CachedImage.SourceProperty, new Binding("Image"));

				TapGestureRecognizer bigt = new TapGestureRecognizer();
				bigt.Tapped += async (object sender, EventArgs e) =>
				{
					if (!noimage)
					{
						UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Gradient);

						try
						{
							ContentPage p = new ContentPage();
							StackLayout st = new StackLayout { Padding = 10, HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
							Xamarin.Forms.RelativeLayout r = new Xamarin.Forms.RelativeLayout();
							CachedImage i = new CachedImage { Aspect = Aspect.Fill, LoadingPlaceholder = ImageSource.FromFile("placeholder.png"), ErrorPlaceholder = ImageSource.FromFile("noimage.gif"), HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
							i.Source = imgAlert.Source;
							i.Aspect = Aspect.AspectFit;
							Xamarin.Forms.AbsoluteLayout a = new Xamarin.Forms.AbsoluteLayout();
							Label l = new Label { TextColor = Color.Black, FontSize = 15 };
							l.Text = ViewModel.device.DeviceDate.ToString("f");
							a.Children.Add(l);
							MyUILibrary.AddView(r, a, w - 80, 50, w, 60);
							st.Children.Add(i);

#if __ANDROID__
					//var activity = Forms.Context as Activity;
					//var tt = activity.FindViewById<TextView>(Resource.Id.toolbar_title);
					//tt.Text = "Alert Image";
#endif
#if __IOS__
							p.Title = "Alert Image";
#endif
							p.Title = "Alert Image";
							p.Content = st;

							await Navigation.PushAsync(p);

						}
						catch
						{
						}
						await System.Threading.Tasks.Task.Delay(50);
						UserDialogs.Instance.HideLoading();
					}
				};
				imgAlert.GestureRecognizers.Add(bigt);

				var customMap = new AlertsMap();

				customMap.MapType = MapType.Satellite;


				if (Device.Idiom == TargetIdiom.Phone)
				{
					customMap.WidthRequest = w / 3;
					customMap.HeightRequest = w / 2;
				}
				else
				{
					if (Device.Idiom == TargetIdiom.Tablet)
					{
						customMap.WidthRequest = App.ScreenWidth/2-10;
						customMap.HeightRequest = App.ScreenWidth/2+App.ScreenWidth / 4;
					}
				}

				var pin = new Pin
				{
					Type = PinType.Place,
					Position = ViewModel.AlertPosition

				};
				var pos = ViewModel.AlertPosition;




				if (Device.Idiom == TargetIdiom.Phone)
				{
					var possibleAddresses = await geoCoder.GetAddressesForPositionAsync(pos);
					foreach (var address in possibleAddresses)
					{
						pin.Address += address + "\n";
						pin.Label = pos.Latitude.ToString() + "," + pos.Longitude.ToString();
					}
				}
				if (pin.Label != null)
				{
					customMap.Pins.Add(pin);
				}
				customMap.MoveToRegion(MapSpan.FromCenterAndRadius(pos, Distance.FromMiles(1.0)));
				TapGestureRecognizer bigMap = new TapGestureRecognizer();
				bigMap.Tapped += async (object sender, EventArgs e) =>
				{
					if (!noMap)
					{
						try
						{
							UserDialogs.Instance.ShowLoading("Loading...");
							ContentPage p = new ContentPage();
							StackLayout st = new StackLayout();
							var Map = new AlertsMap
							{
								MapType = MapType.Street,
								WidthRequest = w,
								HeightRequest = h - 80,
							};
							var pinbig = new Pin
							{
								Type = PinType.Place,
								Position = ViewModel.AlertPosition

							};
							var posi = ViewModel.AlertPosition;
							var Addresses = await geoCoder.GetAddressesForPositionAsync(posi);
							foreach (var address in Addresses)
							{
								pinbig.Address += address + "\n";
								pinbig.Label = posi.Latitude.ToString() + "," + posi.Longitude.ToString();
							}
							Map.Pins.Add(pinbig);
							Map.MoveToRegion(MapSpan.FromCenterAndRadius(posi, Distance.FromMiles(1.0)));
							st.Children.Add(Map);

#if __ANDROID__
					//var activity = Forms.Context as Activity;
					//var tt = activity.FindViewById<TextView>(Resource.Id.toolbar_title);
					//tt.Text = "Alert Position";
#endif
#if __IOS__
							p.Title = "Alert Position";
#endif
							p.Title = "Alert Position";
							p.Content = st;
							System.GC.Collect();


							await Navigation.PushAsync(p);

							await System.Threading.Tasks.Task.Delay(2000);
							UserDialogs.Instance.HideLoading();
						}
						catch
						{
						}
					}
				};

				if (ViewModel.AlertPosition.Latitude == 0 && ViewModel.AlertPosition.Longitude == 0)
				{
					noMap = true;

					var imgGps = new CachedImage()
					{

						CacheDuration = TimeSpan.FromDays(30),
						DownsampleToViewSize = true,
						RetryCount = 0,
						RetryDelay = 250,
						Aspect = Aspect.Fill,
						TransparencyEnabled = false,
						LoadingPlaceholder = ImageSource.FromFile("noimage.gif"),
						ErrorPlaceholder = ImageSource.FromFile("noimage.gif"),
					};
					if (Device.Idiom == TargetIdiom.Phone)
					{
						imgGps.WidthRequest = w / 2;
						imgGps.HeightRequest = w / 2;
					}
					else
					{
						if (Device.Idiom == TargetIdiom.Tablet)
						{
							imgGps.WidthRequest = App.ScreenWidth / 2-10;
							imgGps.HeightRequest = App.ScreenWidth / 2 + App.ScreenWidth / 4;
						}
					}
					if (ViewModel.Gps_enable == true)
					{
						imgGps.Source = "NoGPS_detected.jpg";
					}
					else {
						imgGps.Source = "GPS_disabled.jpg";
					}
				
					//imgGps = MyUILibrary.AddCachedImage(relativeLayout, imgGps, 200, position, 150, 150, Aspect.AspectFit);
					//alertimagestack.Children.Add(imgGps);
					mapstack.Children.Add(imgGps);
				}
				else
				{
					//MyUILibrary.AddMap(relativeLayout, customMap, 200, position, 150, 150);
					//mapstack.Children.Add(customMap);


					var layoutTop = new StackLayout { BackgroundColor = Color.Transparent };
					var relative = new Xamarin.Forms.RelativeLayout { BackgroundColor = Color.Green };
				if (Device.Idiom == TargetIdiom.Phone)
					{
						layoutTop.WidthRequest = w / 2;
						layoutTop.HeightRequest = w / 2;

						//var relative = new Xamarin.Forms.RelativeLayout { BackgroundColor = Color.Green };
						relative.Children.Add(customMap,
						Constraint.Constant(0),
						Constraint.Constant(0),
						Constraint.RelativeToParent((parent) =>
									{

										return w / 2;

									}),
									Constraint.RelativeToParent((parent) =>
									{

										return w / 2;

									}));
						relative.Children.Add(layoutTop,
					Constraint.Constant(0),
					Constraint.Constant(0),
					Constraint.RelativeToParent((parent) =>
								{

									return w / 2;

								}),
								Constraint.RelativeToParent((parent) =>
								{

									return w / 2;

								}));
					}
					else
					{
						if (Device.Idiom == TargetIdiom.Tablet)
						{
							layoutTop.WidthRequest = App.ScreenWidth / 2-10;
							layoutTop.HeightRequest = App.ScreenWidth / 2 + App.ScreenWidth / 4;


							relative.Children.Add(customMap,
							Constraint.Constant(0),
							Constraint.Constant(0),
							Constraint.RelativeToParent((parent) =>
										{

											return App.ScreenWidth / 2 + App.ScreenWidth / 4;

										}),
										Constraint.RelativeToParent((parent) =>
										{

											return App.ScreenWidth / 2+ App.ScreenWidth / 4;

										}));
							relative.Children.Add(layoutTop,
						Constraint.Constant(0),
						Constraint.Constant(0),
						Constraint.RelativeToParent((parent) =>
									{

										return App.ScreenWidth / 2 + App.ScreenWidth / 4;

									}),
									Constraint.RelativeToParent((parent) =>
									{

										return App.ScreenWidth / 2 + App.ScreenWidth / 4;

									}));
						}
					}
		

		
				layoutTop.GestureRecognizers.Add(bigMap);
				mapstack.Children.Add(relative);
				//position += 150 + 10;
					}

				//var imgLine2 = MyUILibrary.AddImage(relativeLayout, "gray_line.png", 0, position, w, 5, Aspect.AspectFit);
				//position += 5;

				//var lblAwakeTime = MyUILibrary.AddLabel(relativeLayout, "Awake Time:", 20, position, newx40, 60, Color.Gray, 14);
				//var lblAwakeTimeValue = MyUILibrary.AddLabel(relativeLayout, "180 secs", (w - newx80) / 2 + 80, position, newx40, 60, Color.Black, 14);

				//imp
				var lblAwakeTime = new Label {Text="Awake Time:",TextColor=Color.Gray,FontSize=14};
				var AwakeSec = ViewModel.device.WakeTime * 60;
				var lblAwakeTimeValue = new Label {TextColor=Color.Black,FontSize=14 };
				lblAwakeTimeValue.SetBinding(Label.TextProperty, new Binding("WakeTime", BindingMode.TwoWay, stringFormat: "" + AwakeSec.ToString() + " Secs"));
				awaketimestack.Children.Add(lblAwakeTime);
				awaketimestack.Children.Add(lblAwakeTimeValue);
				//var lblCountdown = MyUILibrary.AddLabel(relativeLayout, "Countdown:", 200 + 5, position, newx80, 60, Color.Gray, 14);
				//lblCountdownValue = MyUILibrary.AddLabel(relativeLayout, "98 secs", (w - newx80) / 2 + 110 + newx40, position, newx80, 60, Color.Black, 14);

				//imp
				var lblCountdown = new Label {Text="Countdown:",TextColor=Color.Gray,FontSize=14};
				lblCountdownValue = new Label {TextColor=Color.Black,FontSize=14 };
				lblCountdownValue.SetBinding(Label.TextProperty, new Binding("CountDown", BindingMode.TwoWay, stringFormat: "{0} Secs"));
				countdownstack.Children.Add(lblCountdown);
				countdownstack.Children.Add(lblCountdownValue);
				//position += 20;
				//var imgLine3 = MyUILibrary.AddImage(relativeLayout, "gray_line.png", 0, position, w, 5, Aspect.AspectFit);

				//position += 10;
				//var btnAction = MyUILibrary.AddButton(relativeLayout, "Action", 15, position, w / 3, 55, Color.Red, Color.Red, Color.White, 15);
				var btnAction = new Xamarin.Forms.Button { Text="Action", WidthRequest = w / 3, BackgroundColor = Color.Red, TextColor = Color.White, HorizontalOptions = LayoutOptions.Start, VerticalOptions = LayoutOptions.EndAndExpand };
				buttonstack.Children.Add(btnAction);
				//btnAction.IsEnabled = false;

				//var btnArchive = MyUILibrary.AddButton(relativeLayout, "Archive", w / 2 + 40, position, w / 3, 55, Color.Red, Color.Red, Color.White, 15);
				var btnArchive= new Xamarin.Forms.Button { Text = "Archive", WidthRequest = w / 3, BackgroundColor = Color.Red, TextColor = Color.White, HorizontalOptions = LayoutOptions.EndAndExpand, VerticalOptions = LayoutOptions.EndAndExpand };
				buttonstack.Children.Add(btnArchive);

				btnAction.Clicked +=async (sender, e) =>
				{
					UserDialogs.Instance.ShowLoading("Loading");
					await System.Threading.Tasks.Task.Delay(200);
					await Navigation.PushAsync(new AlertDetailsAction(SendToActionPage));
					//await System.Threading.Tasks.Task.Delay(200);
					//UserDialogs.Instance.HideLoading();
				};
				//if (ViewModel.device.EscalateTo == null && ViewModel.device.EscalateToAgentID != null)
				//{
				//	btnAction.IsEnabled = true;
				//	btnAction.Clicked += async (sender, e) =>
				//	{
				//		btnAction.IsEnabled = false;
				//		btnArchive.IsEnabled = false;
				//			try
				//			{
				//				var networkConnection = DependencyService.Get<INetworkConnection>();
				//				networkConnection.CheckNetworkConnection();
				//				var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
				//				if (networkStatus != "Connected")
				//				{
				//					btnAction.IsEnabled = true;
				//					btnArchive.IsEnabled = true;
				//					UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
				//					return;
				//				}
				//				string address = "Are you sure you want to Escalate this Alert ?";
				//				var answer = await UserDialogs.Instance.ConfirmAsync(address, "Confirmation", "Yes", "No");

				//			if (answer == true)
				//			{
				//				UserDialogs.Instance.ShowLoading("Escalating Alert...", Acr.UserDialogs.MaskType.Gradient);
				//				await System.Threading.Tasks.Task.Delay(100);

				//				AlertsEsclatedToAgentViewModel req = new AlertsEsclatedToAgentViewModel();
				//				req.alertlog_idx = ViewModel.device.alertlog_idx;
				//				req.CreatedBy = Settings.UserID;
				//				req.strCreatedDate = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tttt");

				//				var res = await ApiService.Instance.EsclateAlert(req);
				//				if (res > 0)
				//				{
				//					UserDialogs.Instance.HideLoading();
				//					await UserDialogs.Instance.AlertAsync("Alert Escalated Successfully", "Information", "OK");
				//					UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Gradient);
				//				}
				//				else
				//				{
				//					UserDialogs.Instance.HideLoading();
				//					await UserDialogs.Instance.AlertAsync("Alert Not Escalated, Please Consult your System Administrator", "Information", "OK");
				//				    UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Gradient);
				//				}
				//				MyController.fromAssetsToGallery = true;

				//				if (Navigation.NavigationStack.Count <= 1)
				//				{
				//					var mainPage = new MainPage();
				//					var alertListViewModel = new AlertsListViewModel(Navigation, Settings.UserID);
				//					await alertListViewModel.LoadAlertList().ConfigureAwait(true);
				//					mainPage.nav = new NavigationPage(new AlertListPage(0, alertListViewModel));
				//					mainPage.Detail = mainPage.nav;
				//					mainPage.IsPresented = false;

				//					await System.Threading.Tasks.Task.Delay(2000);

				//					Xamarin.Forms.Application.Current.MainPage = mainPage;

				//					UserDialogs.Instance.HideLoading();
				//				}
				//				else
				//				{
				//					await Navigation.PopAsync();
				//					System.GC.Collect();
				//					await System.Threading.Tasks.Task.Delay(1000);
				//					UserDialogs.Instance.HideLoading();
				//				}

				//				btnAction.IsEnabled = true;
				//				btnArchive.IsEnabled = true;

				//			}
				//			else
				//			{  
				//			btnAction.IsEnabled = true;
				//			btnArchive.IsEnabled = true;
				//			}

				//			}
				//			catch { }
				//	} ;
				//}
				//else
				//{
				//	btnAction.Text = "Escalated";
				//}


				btnArchive.Clicked += async (sender, e) =>
			   {

				   try
				   {
					   var networkConnection = DependencyService.Get<INetworkConnection>();
					   networkConnection.CheckNetworkConnection();
					   var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
					   if (networkStatus != "Connected")
					   {

						   UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
						   return;
					   }
					   UserDialogs.Instance.ShowLoading("Loading...");
					   if (Navigation.NavigationStack.Count <= 1)
					   {
						   var mainPage = new MainPage();
						   var alertListViewModel = new AlertsListViewModel(Navigation, Settings.UserID);
						   await alertListViewModel.LoadAlertList().ConfigureAwait(true);
						   mainPage.nav = new NavigationPage(new AlertListPage(0, alertListViewModel));
						   mainPage.Detail = mainPage.nav;
						   mainPage.IsPresented = false;
						   Xamarin.Forms.Application.Current.MainPage = mainPage;
					   }
					   else
					   {
						   await Navigation.PopAsync();
						   System.GC.Collect();
					   }
					   await System.Threading.Tasks.Task.Delay(1000);
					   UserDialogs.Instance.HideLoading();
				   }
				   catch { UserDialogs.Instance.HideLoading(); }
			   };

				//position += 60;
				//var lblMessage = MyUILibrary.AddLabel(relativeLayout, "You don't have any message.", 20, position, w, 60, Color.Gray, 14);

				mainstack.Children.Add(box);
				mainstack.Children.Add(descdetail);
				mainstack.Children.Add(img1);
				mainstack.Children.Add(TSBlayout);
				mainstack.Children.Add(mapandimagestack);
				mainstack.Children.Add(img2);
				mainstack.Children.Add(timestack);
				mainstack.Children.Add(img3);

				var scrl = new Xamarin.Forms.ScrollView { };
				scrl.Content = mainstack;

				var Toplayout = new StackLayout { VerticalOptions = LayoutOptions.StartAndExpand };
				Toplayout.Children.Add(headstack);

				var Top2layout = new StackLayout { VerticalOptions = LayoutOptions.StartAndExpand };
				Toplayout.Children.Add(scrl);

				layout.Children.Add(Toplayout);
				//layout.Children.Add(Toplayout);
				layout.Children.Add(buttonstack);

				Content = layout;
			}
			catch (System.Exception ex)
			{
				//var s = ex;
				//DisplayAlert("Error", ex.StackTrace, "OK");
				UserDialogs.Instance.HideLoading();

			}
		}
		async void Timer()
		{
			try
			{

				DateTime AlertDate = Convert.ToDateTime(ViewModel.device.DeviceDate);
				ViewModel.device.CountDown = ViewModel.device.WakeTime * 60;

				var renainigRtIME = DateTime.Now - AlertDate;

				//var val=TimeSpan.Compare(renainigRtIME, TimeSpan.FromSeconds(Convert.ToDouble(ViewModel.device.WakeTime)));
			
				var CalculatedCountDown  = Convert.ToInt32(ViewModel.device.CountDown)  - Convert.ToInt32(renainigRtIME.Minutes * 60);
				if (CalculatedCountDown >= 0)
				{
					ViewModel.device.CountDown = CalculatedCountDown;
				}
				else
				{
					ViewModel.device.CountDown = 0;
				}
			 

				Device.StartTimer(TimeSpan.FromSeconds(1), () =>
				{
					if (ViewModel != null)
					{
						if (ViewModel.device.CountDown == null)
						{
							return false;
						}

						if (ViewModel.device.CountDown < 0)
						{
							if (lblCountdownValue != null)
							{
								lblCountdownValue.Text = "0 Secs";
							}
							return false;
						}
						else
						{
							if (ViewModel.device.CountDown > 0)
								ViewModel.device.CountDown -= 1;
							if (lblCountdownValue != null)
							{
								lblCountdownValue.Text = ViewModel.device.CountDown.ToString() + " Secs";
							}
						}
					}
					return true;
				});
			}
			catch { }
		}
		protected override bool OnBackButtonPressed()
		{
			try
			{
				System.GC.Collect();

			}
			catch { }
			return base.OnBackButtonPressed();
		}
		public static string BatteryLevelImage(int? BatteryLevel)
		{
			try
			{
				BatteryLevel = BatteryLevel ?? 0;

				if (BatteryLevel <= 10)
				{
					return "battery0.png";
				}
				else if (BatteryLevel > 10 && BatteryLevel <= 40)
				{
					return "battery1.png";
				}

				else if (BatteryLevel > 40 && BatteryLevel <= 70)
				{
					return "battery2.png";
				}
				else
				{
					return "battery3.png";
				}
			}
			catch { }
			return "";
		}
		public static string TempratureLevelImage(int? TempLevel)
		{
			try
			{
				TempLevel = TempLevel ?? 0;

				if (TempLevel <= 10)
				{
					return "temperature0.png";
				}
				else if (TempLevel > 10 && TempLevel <= 40)
				{
					return "temperature1.png";
				}

				else if (TempLevel > 40 && TempLevel <= 70)
				{
					return "temperature2.png";
				}
				else
				{
					return "temperature3.png";
				}
			}
			catch
			{
			}
			return "";
		}
		private Image BytesArraytoImage(byte[] stream)
		{
			Image img = new Image();
			try
			{

				byte[] imagedata = stream;
				img.Source = ImageSource.FromStream(() => new MemoryStream(imagedata));

			}
			catch { }
			return img;
		}
	}
}

