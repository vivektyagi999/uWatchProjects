﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Acr.UserDialogs;
using FFImageLoading.Forms;
using UwatchPCL;
using UwatchPCL.Helpers;
using Xamarin.Forms;
using Xamarin.Forms.Maps;


#if __ANDROID__
using Android.App;
using Android.Widget;
using uWatch.Droid;
using Android.Gms.Gcm;

#endif

namespace uWatch
{
	public partial class AlertDetailsForAgent : ContentPage
	{
		AlertsEsclatedToAgentViewModel Alert;
		Xamarin.Forms.RelativeLayout relativeLayout;
		Xamarin.Forms.ScrollView scrollview;
		public Label lblCountdownValue;
		//public IUserDialogs userdialogs;
		double w = MyController.VirtualWidth;
		double h = MyController.VirtualHeight;
		bool noimage = false;
		bool noMap = false;
		Geocoder geoCoder;

		AlertsEsclatedToAgentViewModel SendToActionPage;

		int GlobleDevceId;

		public AlertDetailsViewModel ViewModel { get; set; }

		public AlertDetailsForAgent(string str = "")
		{

			try
			{
				//userdialogs = UserDialogs.Instance;


				if (!string.IsNullOrEmpty(str))
				{
					var lblMsg = new Label { Text = str, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 15 };
					Content = lblMsg;
				}
				else {

					geoCoder = new Geocoder();
					var alertid = MyController.AlertId;
					AlertsEsclatedToAgentViewModel req = new AlertsEsclatedToAgentViewModel();
					req.alertlog_idx = alertid == "" ? 0 : Convert.ToInt32(alertid);
					var alert = ApiService.Instance.GetAlert(req).Result;
					this.Alert = alert;
					ViewModel = new AlertDetailsViewModel(this.Alert);
					Timer();
					//BindingContext = ViewModel.device;

					SetLayout();
				}
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}
		public AlertDetailsForAgent(AlertsEsclatedToAgentViewModel alert)
		{
			try
			{

				var testingLbl = new Label { Text = "Loading..", VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.CenterAndExpand };
				Content = testingLbl;

				SendToActionPage = alert;
				this.Alert = alert;
				geoCoder = new Geocoder();
				ViewModel = new AlertDetailsViewModel(this.Alert);
				Timer();
				BindingContext = ViewModel.device;
				SetLayout();
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}
		protected async override void OnAppearing()
		{
			base.OnAppearing();
		}

		protected override void OnDisappearing()
		{
			try
			{
				System.GC.Collect();
				base.OnDisappearing();
			}
			catch { }
		}
		private async void SetLayout()
		{
			try
			{
#if __ANDROID__

			//var activity = Forms.Context as Activity;
			//var tt = activity.FindViewById<TextView>(Resource.Id.toolbar_title);
			//tt.Text = "Alerts Details";
#endif
#if __IOS__
				Title = "Alert Details";
#endif
				Title = "Alert Details";
				relativeLayout = new Xamarin.Forms.RelativeLayout();
				AddLayout();
				scrollview = new Xamarin.Forms.ScrollView();
				scrollview.Content = relativeLayout;
				Content = scrollview;
			}
			catch { }
		}
		private async void AddLayout()
		{

			try
			{

				double position = 0;
				double newx20 = MyUiUtils.getPercentual(w, 20);
				double newx40 = MyUiUtils.getPercentual(w, 40);
				double newx60 = MyUiUtils.getPercentual(w, 60);
				double newx80 = MyUiUtils.getPercentual(w, 80);

				//var imgTitle = MyUILibrary.AddImage(relativeLayout, "alert_bg.png", 0, position, w, 100, Aspect.AspectFit);
				//var imgAlertType = MyUILibrary.AddImage(relativeLayout, "Icon.png", 50, position + 20 + 2, 50, 50, Aspect.AspectFit);

				//imgAlertType.HorizontalOptions = LayoutOptions.Center;
				//if (ViewModel != null)
				//	imgAlertType.Source = await MyController.GetAlertTypelImage(ViewModel.device.alert_type);
				//var lblAlertType = MyUILibrary.AddLabel(relativeLayout, "", ((w - newx80) / 2), position + 20 - 3, w, 50, Color.Red, 22);
				//lblAlertType.FontAttributes = FontAttributes.Bold;
				//if (ViewModel != null)
				//	lblAlertType.Text = " !!     " + MyController.GetAlertTypeName(ViewModel.device.alert_type).ToUpper() + " !! ";
				StackLayout layoutstack = new StackLayout { VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand};
				StackLayout mainstack = new StackLayout { };
				//mainstack.HeightRequest = h-h/20;
				mainstack.Padding = new Thickness(12, 0, 12, 10);


				StackLayout mapstack = new StackLayout { VerticalOptions=LayoutOptions.EndAndExpand,HorizontalOptions=LayoutOptions.EndAndExpand};
				StackLayout alertimagestack = new StackLayout {VerticalOptions = LayoutOptions.Start, HorizontalOptions = LayoutOptions.Start };
				StackLayout mapandimagestack = new StackLayout{ Orientation = StackOrientation.Horizontal, Spacing = 2,HorizontalOptions = LayoutOptions.FillAndExpand};
				mapandimagestack.Children.Add(alertimagestack);
				mapandimagestack.Children.Add(mapstack);

				StackLayout buttonstack = new StackLayout { Orientation=StackOrientation.Horizontal,VerticalOptions=LayoutOptions.EndAndExpand, Padding = new Thickness(12,0,12,10)};

				//StackLayout headstack = new StackLayout() { Padding = new Thickness(0, 6, 0, 6) };
				StackLayout headstack = new StackLayout() { BackgroundColor = Color.FromRgb(244, 244, 244), Padding = new Thickness(0, 6, 0, 6)};
				headstack.Orientation = StackOrientation.Horizontal;
				//headstack.HorizontalOptions = LayoutOptions.FillAndExpand;
				//headstack.VerticalOptions = LayoutOptions.StartAndExpand;
				//headstack.HeightRequest = h/4;

				StackLayout Substack = new StackLayout() { Padding = new Thickness(0,10,0,10) };
				Substack.Orientation = StackOrientation.Horizontal;
				Substack.HorizontalOptions = LayoutOptions.CenterAndExpand;
				Substack.VerticalOptions = LayoutOptions.FillAndExpand;
				//Substack.HeightRequest = 30;

				var lblAlertText1 = new Label { Text = "!!", FontSize = 19, FontAttributes = FontAttributes.Bold, TextColor = Color.Red, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };
				var imgAlerts = new Image { HeightRequest = 20, WidthRequest = 20, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };
				if (ViewModel != null)
				{
					if (ViewModel.device != null)
						imgAlerts.Source = await MyController.GetAlertTypelImage(ViewModel.device.alert_type);
				}

				var lblAlertText = new Label { FontSize = 19, FontAttributes = FontAttributes.Bold, TextColor = Color.Red, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };
				if (ViewModel.device != null)
					lblAlertText.Text = MyController.GetAlertTypeName(ViewModel.device.alert_type).ToUpper() + " !! ";

				//headstack.Children.Add(imgTitle);
				Substack.Children.Add(lblAlertText1);
				Substack.Children.Add(imgAlerts);
				Substack.Children.Add(lblAlertText);

				headstack.Children.Add(Substack);

				//MyUILibrary.AddLayout(relativeLayout, headstack, 0, position, w, 50);




				//var lblFirndlyName = MyUILibrary.AddLabel(relativeLayout, SendToActionPage.FriendlyName, 10, position, w, 50, Color.Gray, 19);
				//lblFirndlyName.SetBinding(Label.TextProperty, new Binding("FriendlyName", BindingMode.Default));
				var lblFirndlyName = new Label();
				lblFirndlyName.Text = SendToActionPage.FriendlyName;
				lblFirndlyName.HorizontalTextAlignment = TextAlignment.Start;
				lblFirndlyName.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblFirndlyName.VerticalOptions = LayoutOptions.StartAndExpand;

				//var lblDateText = MyUILibrary.AddLabel(relativeLayout, "AlertDate", 10, position, w, 50, Color.Gray, 19);
				var lblDateText = new Label();
				lblDateText.Text = "AlertDate";
				lblDateText.HorizontalTextAlignment = TextAlignment.Start;
				lblDateText.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblDateText.FontAttributes = FontAttributes.Bold;
				lblDateText.VerticalOptions = LayoutOptions.StartAndExpand;

				//var lblDeviceName = MyUILibrary.AddLabel(relativeLayout, SendToActionPage.DeviceDate.ToString(), 10, position, w, 50, Color.Gray, 19);
				var lblDeviceName = new Label();
				lblDeviceName.Text = SendToActionPage.DeviceDate.ToString();
				lblDeviceName.HorizontalTextAlignment = TextAlignment.Start;
				lblDeviceName.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblDeviceName.VerticalOptions = LayoutOptions.StartAndExpand;







				//var lblAddressText = MyUILibrary.AddLabel(relativeLayout, "Owner's Address", 10, position, w, 50, Color.Gray, 19);
				var addressstacklayout = new StackLayout { };

				var lblAddressText = new Label();
				lblAddressText.Text = "Owner's Address";
				lblAddressText.HorizontalTextAlignment = TextAlignment.Start;
				lblAddressText.FontAttributes = FontAttributes.Bold;
				lblAddressText.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblAddressText.VerticalOptions = LayoutOptions.StartAndExpand;

				//var lblAddressline1 = MyUILibrary.AddLabel(relativeLayout, SendToActionPage.AddressLine1, 10, position, w, 50, Color.Gray, 19);
				var lblAddressline1 = new Label();
				lblAddressline1.Text = SendToActionPage.AddressLine1;
				lblAddressline1.HorizontalTextAlignment = TextAlignment.Start;
				lblAddressline1.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblAddressline1.VerticalOptions = LayoutOptions.StartAndExpand;

				//var lblAddressline2 = MyUILibrary.AddLabel(relativeLayout, SendToActionPage.AddressLine2, 10, position, w, 50, Color.Gray, 19);
				var lblAddressline2 = new Label();
				lblAddressline2.Text = SendToActionPage.AddressLine2;
				lblAddressline2.HorizontalTextAlignment = TextAlignment.Start;
				lblAddressline2.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblAddressline2.VerticalOptions = LayoutOptions.StartAndExpand;

				//var addressline = MyUILibrary.AddImage(relativeLayout, "gray_line.png", 0, position, w, 5, Aspect.AspectFit);


				addressstacklayout.Children.Add(lblFirndlyName);
				addressstacklayout.Children.Add(lblDateText);
				addressstacklayout.Children.Add(lblDeviceName);
				addressstacklayout.Children.Add(lblAddressText);
				addressstacklayout.Children.Add(lblAddressline1);
				addressstacklayout.Children.Add(lblAddressline2);
			
				//var lblcontactText = MyUILibrary.AddLabel(relativeLayout, "Contact: " + SendToActionPage.Mobile1, 10, position, w, 50, Color.Gray, 19);
				var contactlayout = new StackLayout { };

				var lblcontactText = new Label();
				lblcontactText.Text = "Contact: " + SendToActionPage.Mobile1;
				lblcontactText.HorizontalTextAlignment = TextAlignment.Start;
				lblcontactText.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblcontactText.VerticalOptions = LayoutOptions.StartAndExpand;

				//var lblcontact = MyUILibrary.AddLabel(relativeLayout, SendToActionPage.Mobile1, 10, position, w, 50, Color.Gray, 19);
				//lblcontact.HorizontalTextAlignment = TextAlignment.Start;
				//lblcontact.HorizontalOptions = LayoutOptions.FillAndExpand;
				//lblcontact.VerticalOptions = LayoutOptions.StartAndExpand;

				//var contactline = MyUILibrary.AddImage(relativeLayout, "gray_line.png", 0, position, w, 5, Aspect.AspectFit);


				contactlayout.Children.Add(lblcontactText);
			
				//var lblAlertDateTime = MyUILibrary.AddLabel(relativeLayout, SendToActionPage.AlertDateTime, 10, position, w, 50, Color.Gray, 19);
				//var alertdate = ViewModel.device.DeviceDate.ToString("dddd dd-MMM hh:mm:tt");
				//lblAlertDateTime.SetBinding(Label.TextProperty, new Binding("DeviceDate", BindingMode.Default, stringFormat: alertdate));
				var lblAlertDateTime = new Label();
				lblAlertDateTime.Text = SendToActionPage.AlertDateTime;
				lblAlertDateTime.HorizontalTextAlignment = TextAlignment.Start;
				lblAlertDateTime.HorizontalOptions = LayoutOptions.FillAndExpand;
				lblAlertDateTime.VerticalOptions = LayoutOptions.StartAndExpand;

				//position += 30;
				//var imgLine = MyUILibrary.AddImage(relativeLayout, "gray_line.png", 0, position, w, 5, Aspect.AspectFit);

				//position += 10;
				//var lblTemp = MyUILibrary.AddLabel(relativeLayout, "Temp.", (w - newx80) / 2, position, newx80, 60, Color.Gray, 18);
				//var lblSignal = MyUILibrary.AddLabel(relativeLayout, "Signal", (w - newx80) / 2 + 120, position, newx80, 60, Color.Gray, 18);
				//var lblBattery = MyUILibrary.AddLabel(relativeLayout, "Battery", (w - newx80) / 2 + 240, position, newx80, 60, Color.Gray, 18);

				//position += 15;
				//var imgTemp = MyUILibrary.AddImage(relativeLayout, "Icon.png", (w - newx80) / 2, position + 10, 75, 50, Aspect.AspectFit);
				//imgTemp.SetBinding(Image.SourceProperty, new Binding("TemperatureImage", BindingMode.Default));

				//var imgSignal = MyUILibrary.AddImage(relativeLayout, "Icon.png", (w - newx80) / 2 + 120 - 10, position, 75, 75, Aspect.AspectFit);
				//imgSignal.SetBinding(Image.SourceProperty, new Binding("SignalImage", BindingMode.Default));

				//var imgBattery = MyUILibrary.AddImage(relativeLayout, "Icon.png", (w - newx80) / 2 + 240, position + 10, 75, 75, Aspect.AspectFit);
				//imgBattery.SetBinding(Image.SourceProperty, new Binding("BatteryImage", BindingMode.Default));

				//position += 60;
				//var lblTempValue = MyUILibrary.AddLabel(relativeLayout, "Temp.", (w - newx80) / 2 + 10, position, newx80, 60, Color.Gray, 18);
				//lblTempValue.SetBinding(Label.TextProperty, new Binding("DegC", BindingMode.Default, stringFormat: "{0}.C"));

				//var lblSignalValue = MyUILibrary.AddLabel(relativeLayout, "Signal", (w - newx80) / 2 + 120 + 10, position, newx80, 60, Color.Gray, 18);
				//lblSignalValue.SetBinding(Label.TextProperty, new Binding("Signal", BindingMode.Default, stringFormat: "{0}%"));

				//var lblBatteryValue = MyUILibrary.AddLabel(relativeLayout, "Battery", (w - newx80) / 2 + 240 + 10, position, newx80, 60, Color.Gray, 18);
				//lblBatteryValue.SetBinding(Label.TextProperty, new Binding("Battery", BindingMode.Default, stringFormat: "{0}%"));


				var imgAlert = new CachedImage()
				{
					WidthRequest = w/2-20,
					HeightRequest = w/2-20,
					CacheDuration = TimeSpan.FromDays(30),
					DownsampleToViewSize = true,
					RetryCount = 300,
					RetryDelay = 250,
					Aspect = Aspect.AspectFit,
					TransparencyEnabled = false,
					LoadingPlaceholder = ImageSource.FromFile("noimage.gif"),
					ErrorPlaceholder = ImageSource.FromFile("noimage.gif"),
				};

				//imgAlert = MyUILibrary.AddCachedImage(relativeLayout, imgAlert, 20, position, 150, 150, Aspect.AspectFit);
				alertimagestack.Children.Add(imgAlert);
				if (ViewModel != null)
				{
					if (ViewModel.AlertImage != null)
					{
						if (ViewModel.AlertImage.Image != null)
						{
							imgAlert.Source = BytesArraytoImage(ViewModel.AlertImage.Image).Source as StreamImageSource;
						}
						else
						{
							noimage = true;
							imgAlert.Source = ImageSource.FromFile("noimage.gif");
						}
					}
					else
					{
						noimage = true;
						imgAlert.Source = ImageSource.FromFile("noimage.gif");
					}
				}
				//imgAlert.SetBinding(CachedImage.SourceProperty, new Binding("Image"));

				TapGestureRecognizer bigt = new TapGestureRecognizer();
				bigt.Tapped += async (object sender, EventArgs e) =>
				{
					if (!noimage)
					{
						UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Gradient);

						try
						{
							ContentPage p = new ContentPage();
							StackLayout st = new StackLayout { Padding = 10, HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
							Xamarin.Forms.RelativeLayout r = new Xamarin.Forms.RelativeLayout();
							CachedImage i = new CachedImage { Aspect = Aspect.Fill, LoadingPlaceholder = ImageSource.FromFile("placeholder.png"), ErrorPlaceholder = ImageSource.FromFile("noimage.gif"), HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.FillAndExpand };
							i.Source = imgAlert.Source;
							i.Aspect = Aspect.AspectFit;
							Xamarin.Forms.AbsoluteLayout a = new Xamarin.Forms.AbsoluteLayout();
							Label l = new Label { TextColor = Color.Black, FontSize = 15 };
							//l.Text = ViewModel.device.DeviceDate.ToString("f");
							a.Children.Add(l);
							MyUILibrary.AddView(r, a, w - 80, 50, w, 60);
							st.Children.Add(i);

#if __ANDROID__
					//var activity = Forms.Context as Activity;
					//var tt = activity.FindViewById<TextView>(Resource.Id.toolbar_title);
					//tt.Text = "Alert Image";
#endif
#if __IOS__
							p.Title = "Alert Image";
#endif
							p.Title = "Alert Image";
							p.Content = st;

							await Navigation.PushAsync(p);

						}
						catch
						{
						}
						await System.Threading.Tasks.Task.Delay(50);
						UserDialogs.Instance.HideLoading();
					}
				};
				imgAlert.GestureRecognizers.Add(bigt);

				var customMap = new AlertsMap
				{
					MapType = MapType.Satellite,
					WidthRequest = w/2-20,
					HeightRequest =w/2-20,
				};
				var pin = new Pin
				{
					Type = PinType.Place,
					Position = ViewModel.AlertPosition

				};
				var pos = ViewModel.AlertPosition;




				if (Device.Idiom == TargetIdiom.Phone)
				{
					var possibleAddresses = await geoCoder.GetAddressesForPositionAsync(pos);
					foreach (var address in possibleAddresses)
					{
						pin.Address += address + "\n";
						pin.Label = pos.Latitude.ToString() + "," + pos.Longitude.ToString();
					}
				}
				customMap.Pins.Add(pin);
				customMap.MoveToRegion(MapSpan.FromCenterAndRadius(pos, Distance.FromMiles(1.0)));
				TapGestureRecognizer bigMap = new TapGestureRecognizer();
				bigMap.Tapped += async (object sender, EventArgs e) =>
				{
					if (!noMap)
					{
						try
						{
							UserDialogs.Instance.ShowLoading("Loading...");
							ContentPage p = new ContentPage();
							StackLayout st = new StackLayout();
							var Map = new AlertsMap
							{
								MapType = MapType.Street,
								WidthRequest = w,
								HeightRequest = h - 80,
							};
							var pinbig = new Pin
							{
								Type = PinType.Place,
								Position = ViewModel.AlertPosition

							};
							var posi = ViewModel.AlertPosition;
							var Addresses = await geoCoder.GetAddressesForPositionAsync(posi);
							foreach (var address in Addresses)
							{
								pinbig.Address += address + "\n";
								pinbig.Label = posi.Latitude.ToString() + "," + posi.Longitude.ToString();
							}
							Map.Pins.Add(pinbig);
							Map.MoveToRegion(MapSpan.FromCenterAndRadius(posi, Distance.FromMiles(1.0)));
							st.Children.Add(Map);

#if __ANDROID__
					//var activity = Forms.Context as Activity;
					//var tt = activity.FindViewById<TextView>(Resource.Id.toolbar_title);
					//tt.Text = "Alert Position";
#endif
#if __IOS__
							p.Title = "Alert Position";
#endif
							p.Title = "Alert Position";
							p.Content = st;
							System.GC.Collect();


							await Navigation.PushAsync(p);

							await System.Threading.Tasks.Task.Delay(2000);
							UserDialogs.Instance.HideLoading();
						}
						catch
						{
						}
					}
				};
				if (ViewModel.AlertPosition.Latitude.ToString() == "0" && ViewModel.AlertPosition.Longitude.ToString() == "0")
				{
					noMap = true;

					var imgGps = new CachedImage()
					{
						WidthRequest = w/3,
						HeightRequest = h/3,
						CacheDuration = TimeSpan.FromDays(30),
						DownsampleToViewSize = true,
						RetryCount = 0,
						RetryDelay = 250,
						Aspect = Aspect.AspectFit,
						TransparencyEnabled = false,
						LoadingPlaceholder = ImageSource.FromFile("noimage.gif"),
						ErrorPlaceholder = ImageSource.FromFile("noimage.gif"),
					};
					imgGps.Source = ImageSource.FromFile("nogps.gif");

					//imgGps = MyUILibrary.AddCachedImage(relativeLayout, imgGps, 200, position, 150, 150, Aspect.AspectFit);
					mapstack.Children.Add(imgGps);
				}
				else {
					//mapstack.Children.Add(customMap);
					//MyUILibrary.AddMap(relativeLayout, customMap, 200, position, 150, 150);


				
				var layoutTop = new StackLayout { BackgroundColor = Color.Transparent, HeightRequest = 100, WidthRequest = 100 };

				var relative = new Xamarin.Forms.RelativeLayout { BackgroundColor = Color.Green };
				relative.Children.Add(customMap,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) =>
							{

								return w / 3;

							}),
							Constraint.RelativeToParent((parent) =>
							{

								return w / 3;

							}));
				relative.Children.Add(layoutTop,
			Constraint.Constant(0),
			Constraint.Constant(0),
			Constraint.RelativeToParent((parent) =>
						{

							return w / 3;

						}),
						Constraint.RelativeToParent((parent) =>
						{

							return w / 3;

						}));


				relative.GestureRecognizers.Add(bigMap);
				mapstack.Children.Add(relative);
					}
				//position += 150 + 10;


				//var imgLine2 = MyUILibrary.AddImage(relativeLayout, "gray_line.png", 0, position, w, 5, Aspect.AspectFit);
				//position += 5;

				//	var lblAwakeTime = MyUILibrary.AddLabel(relativeLayout, "Awake Time:", 20, position, newx40, 60, Color.Gray, 14);
				//	var lblAwakeTimeValue = MyUILibrary.AddLabel(relativeLayout, "180 secs", (w - newx80) / 2 + 80, position, newx40, 60, Color.Black, 14);
				//	//var AwakeSec = ViewModel.device.WakeTime * 60;
				////	lblAwakeTimeValue.SetBinding(Label.TextProperty, new Binding("WakeTime", BindingMode.TwoWay, stringFormat: "" + AwakeSec.ToString() + " Secs"));
				//	var lblCountdown = MyUILibrary.AddLabel(relativeLayout, "Countdown:", 200 + 5, position, newx80, 60, Color.Gray, 14);
				//	lblCountdownValue = MyUILibrary.AddLabel(relativeLayout, "98 secs", (w - newx80) / 2 + 110 + newx40, position, newx80, 60, Color.Black, 14);
				//	lblCountdownValue.SetBinding(Label.TextProperty, new Binding("CountDown", BindingMode.TwoWay, stringFormat: "{0} Secs"));

				//position += 20;
				//var imgLine3 = MyUILibrary.AddImage(relativeLayout, "gray_line.png", 0, position, w, 5, Aspect.AspectFit);

				//position += 10;
				var btnAction = new Xamarin.Forms.Button { Text ="Action",WidthRequest=w/3,BackgroundColor=Color.Red,TextColor=Color.White,HorizontalOptions=LayoutOptions.Start,VerticalOptions=LayoutOptions.EndAndExpand};
				//var btnAction = MyUILibrary.AddButton(relativeLayout, "Action", 15, position, w / 3, 55, Color.Red, Color.Red, Color.White, 15);
				//btnAction.IsEnabled = false;

				//var btnArchive = MyUILibrary.AddButton(relativeLayout, "Archive", w / 2 + 40, position, w / 3, 55, Color.Red, Color.Red, Color.White, 15);
				var btnArchive = new Xamarin.Forms.Button { Text = "Archive",WidthRequest = w / 3, BackgroundColor = Color.Red, TextColor = Color.White, HorizontalOptions = LayoutOptions.EndAndExpand, VerticalOptions = LayoutOptions.EndAndExpand};

				buttonstack.Children.Add(btnAction);
				buttonstack.Children.Add(btnArchive);

				btnAction.Clicked += (sender, e) =>
				{

					Navigation.PushAsync(new AlertDetailsAction(SendToActionPage));
				};
				//if (ViewModel.device.EscalateTo == null && ViewModel.device.EscalateToAgentID != null)
				//{
				//	btnAction.IsEnabled = true;
				//	btnAction.Clicked += async (sender, e) =>
				//	{
				//		btnAction.IsEnabled = false;
				//		btnArchive.IsEnabled = false;
				//			try
				//			{
				//				var networkConnection = DependencyService.Get<INetworkConnection>();
				//				networkConnection.CheckNetworkConnection();
				//				var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
				//				if (networkStatus != "Connected")
				//				{
				//					btnAction.IsEnabled = true;
				//					btnArchive.IsEnabled = true;
				//					UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
				//					return;
				//				}
				//				string address = "Are you sure you want to Escalate this Alert ?";
				//				var answer = await UserDialogs.Instance.ConfirmAsync(address, "Confirmation", "Yes", "No");

				//			if (answer == true)
				//			{
				//				UserDialogs.Instance.ShowLoading("Escalating Alert...", Acr.UserDialogs.MaskType.Gradient);
				//				await System.Threading.Tasks.Task.Delay(100);

				//				AlertsEsclatedToAgentViewModel req = new AlertsEsclatedToAgentViewModel();
				//				req.alertlog_idx = ViewModel.device.alertlog_idx;
				//				req.CreatedBy = Settings.UserID;
				//				req.strCreatedDate = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tttt");

				//				var res = await ApiService.Instance.EsclateAlert(req);
				//				if (res > 0)
				//				{
				//					UserDialogs.Instance.HideLoading();
				//					await UserDialogs.Instance.AlertAsync("Alert Escalated Successfully", "Information", "OK");
				//					UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Gradient);
				//				}
				//				else
				//				{
				//					UserDialogs.Instance.HideLoading();
				//					await UserDialogs.Instance.AlertAsync("Alert Not Escalated, Please Consult your System Administrator", "Information", "OK");
				//				    UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Gradient);
				//				}
				//				MyController.fromAssetsToGallery = true;

				//				if (Navigation.NavigationStack.Count <= 1)
				//				{
				//					var mainPage = new MainPage();
				//					var alertListViewModel = new AlertsListViewModel(Navigation, Settings.UserID);
				//					await alertListViewModel.LoadAlertList().ConfigureAwait(true);
				//					mainPage.nav = new NavigationPage(new AlertListPage(0, alertListViewModel));
				//					mainPage.Detail = mainPage.nav;
				//					mainPage.IsPresented = false;

				//					await System.Threading.Tasks.Task.Delay(2000);

				//					Xamarin.Forms.Application.Current.MainPage = mainPage;

				//					UserDialogs.Instance.HideLoading();
				//				}
				//				else
				//				{
				//					await Navigation.PopAsync();
				//					System.GC.Collect();
				//					await System.Threading.Tasks.Task.Delay(1000);
				//					UserDialogs.Instance.HideLoading();
				//				}

				//				btnAction.IsEnabled = true;
				//				btnArchive.IsEnabled = true;

				//			}
				//			else
				//			{  
				//			btnAction.IsEnabled = true;
				//			btnArchive.IsEnabled = true;
				//			}

				//			}
				//			catch { }
				//	} ;
				//}
				//else
				//{
				//	btnAction.Text = "Escalated";
				//}


				btnArchive.Clicked += async (sender, e) =>
			   {

				   try
				   {
					   var networkConnection = DependencyService.Get<INetworkConnection>();
					   networkConnection.CheckNetworkConnection();
					   var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
					   if (networkStatus != "Connected")
					   {

						   UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
						   return;
					   }
					   UserDialogs.Instance.ShowLoading("Loading...");
					   if (Navigation.NavigationStack.Count <= 1)
					   {
						   var mainPage = new MainPage();
						   var alertListViewModel = new AlertsListViewModel(Navigation, Settings.UserID);
						   await alertListViewModel.LoadAlertList().ConfigureAwait(true);
						   mainPage.nav = new NavigationPage(new AlertListPage(0, alertListViewModel));
						   mainPage.Detail = mainPage.nav;
						   mainPage.IsPresented = false;
						   Xamarin.Forms.Application.Current.MainPage = mainPage;
					   }
					   else
					   {
						   await Navigation.PopAsync();
						   System.GC.Collect();
					   }
					   await System.Threading.Tasks.Task.Delay(1000);
					   UserDialogs.Instance.HideLoading();
				   }
				   catch { UserDialogs.Instance.HideLoading(); }
			   };

				//position += 60;
				//var lblMessage = MyUILibrary.AddLabel(relativeLayout, "You don't have any message.", 20, position, w, 60, Color.Gray, 14);
				//position += 60;
				//mainstack.Children.Add(headstack);
				mainstack.Children.Add(addressstacklayout);
				mainstack.Children.Add(mapandimagestack);
				//mainstack.Children.Add(Maplayout);
			//	mainstack.Children.Add(buttonstack);

				layoutstack.Children.Add(headstack);
				layoutstack.Children.Add(mainstack);
				layoutstack.Children.Add(buttonstack);
				//var scr = new ScrollView { };
				//scr.Content = layoutstack;
				Content = layoutstack;
			}
			catch { }
		}
		async void Timer()
		{
			try
			{
				Device.StartTimer(TimeSpan.FromSeconds(1), () =>
				{
					if (ViewModel != null)
					{
						//if (ViewModel.device.CountDown < 0)
						//{
						//	return false;
						//}
						//if (ViewModel.device.CountDown > 0)
						//	ViewModel.device.CountDown -= 1;
						//if (lblCountdownValue != null)
						//{
						//	lblCountdownValue.Text = ViewModel.device.CountDown.ToString() + " Secs";
						//}
					}
					return true;
				});
			}
			catch { }
		}

		protected override bool OnBackButtonPressed()
		{
			try
			{
				System.GC.Collect();

			}
			catch { }
			return base.OnBackButtonPressed();
		}
		public static string BatteryLevelImage(int? BatteryLevel)
		{
			try
			{
				BatteryLevel = BatteryLevel ?? 0;

				if (BatteryLevel <= 10)
				{
					return "battery0.png";
				}
				else if (BatteryLevel > 10 && BatteryLevel <= 40)
				{
					return "battery1.png";
				}

				else if (BatteryLevel > 40 && BatteryLevel <= 70)
				{
					return "battery2.png";
				}
				else
				{
					return "battery3.png";
				}
			}
			catch { }
			return "";
		}
		public static string TempratureLevelImage(int? TempLevel)
		{
			try
			{
				TempLevel = TempLevel ?? 0;

				if (TempLevel <= 10)
				{
					return "temperature0.png";
				}
				else if (TempLevel > 10 && TempLevel <= 40)
				{
					return "temperature1.png";
				}

				else if (TempLevel > 40 && TempLevel <= 70)
				{
					return "temperature2.png";
				}
				else
				{
					return "temperature3.png";
				}
			}
			catch
			{
			}
			return "";
		}
		private Image BytesArraytoImage(byte[] stream)
		{
			Image img = new Image();
			try
			{

				byte[] imagedata = stream;
				img.Source = ImageSource.FromStream(() => new MemoryStream(imagedata));

			}
			catch { }
			return img;
		}
	}
}

