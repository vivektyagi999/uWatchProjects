﻿using System;
using System.Linq;
using uWatch.ViewModels;
using UwatchPCL;
using Xamarin.Forms;
using System.IO;
using Acr.UserDialogs;
using System.Threading.Tasks;
using UwatchPCL.Model;
using FFImageLoading.Forms;
using uwatch.ViewModels;
using UwatchPCL.Helpers;

#if __ANDROID__
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using Android.App;
using Android.Widget;
using uWatch.Droid;
#endif

#if __IOS__
using Xamarin.Media;
#endif
#if __ANDROID__
using Xamarin.Media;
#endif

namespace uWatch
{
	public partial class DevicesPage : ContentPage
	{
		public static bool IsList;
		public INavigation _navigation { get; set; }
		double pddingH, paddingW;
		private ImageSource picture;
		Label lblHelp;
		StackLayout mainlayoutGallery;
		Xamarin.Forms.Button btnAdd;
		public ImageSource Picture
		{
			get
			{
				return this.picture;
			}
			set
			{
				if (Equals(value, this.picture))
				{
					return;
				}
				this.picture = value;
				OnPropertyChanged();
			}
		}

		public int countAssets = 0;
		bool backpressed = false;
		Xamarin.Forms.RelativeLayout relativeLayout;
		Xamarin.Forms.ScrollView scrollview;
		int currentimg = 0;
		Image imgAsset;

		double w = MyController.VirtualWidth;
		double h = MyController.VirtualHeight;
		public InfiniteListView listView;

		public bool MoreThanOneDevices { get; set; }

		public DeviceStatic device { get; set; }
		public DataTemplate Cell { get; private set; }

		public DashboardViewModel ViewModelDevices { get; set; }

		public TakePictureViewModel AssetViewModel { get; set; }
		public DeviceDetailsViewModel ViewModel { get; set; }

		public DevicesPage(DashboardViewModel assetsViewModel = null)
		{
			try
			{
				MyController.fromAssetsToGallery = false;
				this.ViewModelDevices = assetsViewModel;
				InitializeComponent();
				AssetViewModel = new TakePictureViewModel();

				if (ViewModelDevices.DeviceList.Count > 1)
				{
					IsList = true;
					SetLayout(true);
				}
				else if (ViewModelDevices.DeviceList.Count == 1)
				{
					IsList = false;

					this.device = ViewModelDevices.DeviceList[0];
					backpressed = true;
					SetLayout();
				}
				else
				{
					relativeLayout = new Xamarin.Forms.RelativeLayout();
					var lblError = MyUILibrary.AddLabel(relativeLayout, "No Assets to Display", 20, 150, w - 40, 55, Color.Blue, 20);
					lblError.HorizontalOptions = LayoutOptions.CenterAndExpand;
					scrollview = new Xamarin.Forms.ScrollView();
					scrollview.Content = relativeLayout;


					var custom = new CustomPopup();
					var popupLayouts = this.Content as CustomPopup;
					Content = custom;
					custom.Content = scrollview;

					//Content = scrollview;
				}
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}

		public DevicesPage(DeviceDetailsViewModel assetViewModel)
		{
			try
			{
				this.ViewModel = assetViewModel;
				if (ViewModel.device != null)
					this.device = ViewModel.device;
				AssetViewModel = new TakePictureViewModel();
				InitializeComponent();
				IsList = false;
				SetLayout();
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}

#if __ANDROID__
		async Task<bool> CheckCameraPermisions()
		{
			var results = false;
			try
			{
				var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Plugin.Permissions.Abstractions.Permission.Storage);
				if (status != PermissionStatus.Granted)
				{
					if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Plugin.Permissions.Abstractions.Permission.Storage))
					{
						await DisplayAlert("Need Storage", "uWatch need to access your device storage", "OK");
					}

					var r = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Plugin.Permissions.Abstractions.Permission.Storage });
					status = r[Plugin.Permissions.Abstractions.Permission.Storage];
				}
				if (status == PermissionStatus.Granted)
				{
					results = true;
				}
				else if (status != PermissionStatus.Unknown)
				{
					await DisplayAlert("Storage access Denied", "Can not continue, try again.", "OK");
				}
			}
			catch (Exception ex)
			{
				results = false;
				MyController.ErrorManagement(ex.Message);
			}
			return results;
		}
#endif
		protected async override void OnAppearing()
		{
#if __ANDROID__
			var s = await CheckCameraPermisions();
			if (s)
			{
				base.OnAppearing();
			}
			else
			{
				await Navigation.PopAsync(true);
			}
#endif
#if __IOS__
			base.OnAppearing();
#endif

			try
			{
				if (MyController.fromAssetsToGallery == true)
				{
					var networkConnection = DependencyService.Get<INetworkConnection>();
					networkConnection.CheckNetworkConnection();
					var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
					if (networkStatus != "Connected")
					{
						MyController.fromAssetsToGallery = false;
						UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
						return;
					}
					using (UserDialogs.Instance.Loading("Loading.."))
					{
						//await Task.Delay(100);
						ViewModel = new DeviceDetailsViewModel(this.device.device_idx);
						var Assets = await ViewModel.GetDeviceAssets(device.device_idx);
						if (this.device != null)
							//SetLayout();
							if (!IsList)
							{
								SetLayout();
							}
							else {
								GetPopupofAssetsImage(true);
							}
							//GetPopupofAssetsImage(true);
					}
					MyController.fromAssetsToGallery = false;
				}
			}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}

		}

		private async Task AddLayoutForDevices()
		{
			try
			{
				listView = new InfiniteListView();
				listView.BackgroundColor = Color.FromRgb(247, 247, 247);
				listView.BindingContext = ViewModelDevices;
				listView.SetBinding(Xamarin.Forms.ListView.ItemsSourceProperty, new Binding("DeviceList", BindingMode.TwoWay));
				listView.LoadMoreCommand = ViewModelDevices.LoadCharactersCommand;


				Cell = new DataTemplate(typeof(DeviceListCell));
				listView.ItemTemplate = Cell;




				//	Cell.SetBinding(TextCell.TextProperty, new Binding("FriendlyName", stringFormat: "Device Name: {0}"));
				//	Cell.SetBinding(TextCell.DetailProperty, new Binding("imei", stringFormat: "IMEI: {0}"));

				listView.ItemSelected += async (sender, e) =>
				   {
					   try
					   {
						   var networkConnection = DependencyService.Get<INetworkConnection>();
						   networkConnection.CheckNetworkConnection();
						   var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
						   if (networkStatus != "Connected")
						   {
							   UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
							   return;
						   }
						   UserDialogs.Instance.ShowLoading("Loading...");
						   await Task.Delay(5);

						   if (e.SelectedItem == null)
							   return;

						   this.device = e.SelectedItem as DeviceStatic;
						   this.device.OwnerUserID = Settings.UserID;

						   ViewModel = new DeviceDetailsViewModel(this.device.device_idx);
						   if (ViewModel.AssetsList == null)
							   ViewModel.AssetsList = new System.Collections.ObjectModel.ObservableCollection<DeviceAssetsModel>();
						   ViewModel.AssetsList = await ViewModel.GetDeviceAssets(device.device_idx);
						   ViewModel.device = this.device;


						   listView.SelectedItem = null;
						   System.GC.Collect();
						   // await Task.Delay(150);
						   GetPopupofAssetsImage(false);
						   // await Navigation.PushAsync(new DevicesPage(ViewModel));
						   UserDialogs.Instance.HideLoading();


					   }
					   catch (Exception ex)
					   {
					   }
				   };
				double newx80 = MyUiUtils.getPercentual(w, 80);
				double newy30 = MyUiUtils.getPercentual(h, 30);

				if (ViewModelDevices.DeviceList.Count > 0)
				{
					MyUILibrary.AddListView(relativeLayout, listView, 0, 0, w, h - 80, listView.SeparatorColor, 220);
				}
				else
				{
					var lblerror = MyUILibrary.AddLabel(relativeLayout, "No devices to display, please register your device", (w - newx80) / 2, newy30, w - 30, 500, listView.SeparatorColor, 18);
				}

				//	MyUILibrary.AddListView(relativeLayout, listView, 0, 0, w, h - 80, listView.SeparatorColor, 80);
			}
			catch (System.Exception ex)
			{
				UserDialogs.Instance.HideLoading();
			}
		}


		private async void SetLayout(bool moredevices = false)
		{
			try
			{
#if __ANDROID__

			//var activity = Forms.Context as Activity;
			//var tt = activity.FindViewById<TextView>(Resource.Id.toolbar_title);
			//tt.Text = "Devices";
#endif
#if __IOS__
				Title = "Devices";
#endif
				Title = "Devices";
				relativeLayout = new Xamarin.Forms.RelativeLayout();

				if (!moredevices)
				{
					AddLayout();
				}
				else
				{
					await AddLayoutForDevices();
				}
				scrollview = new Xamarin.Forms.ScrollView();
				scrollview.Content = relativeLayout;
				//Content = relativeLayout;
				var custom = new CustomPopup();
				var popupLayouts = this.Content as CustomPopup;
				Content = custom;
				custom.Content = relativeLayout;
			}
			catch { }
		}

private async Task AddLayout()
		{
			try
			{
				Xamarin.Forms.StackLayout relativeLayouts = new Xamarin.Forms.StackLayout();
				relativeLayouts.VerticalOptions = LayoutOptions.StartAndExpand;
				//relativeLayouts.BackgroundColor = Color.Silver;
				double position = 0;
				double newx20 = MyUiUtils.getPercentual(w, 20);
				double newx40 = MyUiUtils.getPercentual(w, 40);
				double newx60 = MyUiUtils.getPercentual(w, 60);
				double newx80 = MyUiUtils.getPercentual(w, 80);

				var x = 10;
				var z = 10;
				var i = 0;
				var lblname = new Label { Text = "Device:", TextColor = Color.Black, FontSize = 16, WidthRequest = 75, };
				//MyUILibrary.AddLabel(relativeLayout, "Device:", x, position + 10, w, 50, Color.Black, 16);
				var LblDvice = new Label { TextColor = Color.Black, FontSize = 15 };
				LblDvice.LineBreakMode = LineBreakMode.WordWrap;
				if (MyController.Roll_id != 8)
				{
					if (device != null && (!string.IsNullOrEmpty(device.FriendlyName)))
						LblDvice.Text = "Device: " + device.FriendlyName.ToString();
					else
						LblDvice.Text = "Device: " + "Asset Images";
				}
				else
				{
					LblDvice.Text = "Device: " + "Asset Images";
				}
				var layoutGllry1 = new StackLayout { Orientation = StackOrientation.Horizontal, VerticalOptions = LayoutOptions.StartAndExpand };
				var layoutGllry2 = new StackLayout { Orientation = StackOrientation.Horizontal, VerticalOptions = LayoutOptions.StartAndExpand };

				StackLayout st = new StackLayout() { Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.StartAndExpand };
				//st.Children.Add(lblname);
				st.Children.Add(LblDvice);

				MyUILibrary.AddLayout(relativeLayout, st, x + 20, position + 10, w - 20, 50);

				if (ViewModel != null && ViewModel.AssetsList != null)
				{
					countAssets = ViewModel.AssetsList.Count;
					if (ViewModel.ImageList != null)
					{
						if (ViewModel.ImageList.Count() > 0)
						{
							int CountOfImage = 1;
							foreach (var item in ViewModel.AssetsList)
							{
								var it = new CachedImage()
								{
									WidthRequest = MyController.ScreenWidth / 4 - 10,
									HeightRequest = MyController.ScreenWidth / 4 - 10,
									CacheDuration = TimeSpan.FromDays(30),
									DownsampleToViewSize = true,
									RetryCount = 0,
									RetryDelay = 250,
									TransparencyEnabled = false,
									Aspect = Aspect.AspectFit,
									Source = ImageSource.FromFile("noimage.gif"),
								};
								var layout = new Xamarin.Forms.RelativeLayout();
								layout.Padding = 2;
								layout.Children.Add(it, Constraint.Constant(0), Constraint.Constant(0));
								layout.BackgroundColor = Color.White;

								var sou = await ModeltoImage(item);
								it.Source = sou.Source as ImageSource;
								var frm = new Frame { Padding = 1, HasShadow = false, BackgroundColor = Color.Silver };
								frm.Content = it;
								if (CountOfImage < 5)
								{
									layoutGllry1.Children.Add(frm);
									//frm = MyUILibrary.AddnewFrame(relativeLayouts, frm, x - 5, position + 40, 80, 80);
								}
								else {
									layoutGllry2.Children.Add(frm);
									//frm = MyUILibrary.AddnewFrame(relativeLayouts, frm, z-5, position + 100, 80, 80);
									//z += 50 + 40;
									z += 80;
								}
								relativeLayouts.Children.Add(layoutGllry1);
								relativeLayouts.Children.Add(layoutGllry2);

								TapGestureRecognizer bigt = new TapGestureRecognizer();
								bigt.Tapped += async (object sender, EventArgs e) =>
								{
									//popupLayouts.DismissPopup();
									var networkConnection = DependencyService.Get<INetworkConnection>();
									networkConnection.CheckNetworkConnection();
									var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
									if (networkStatus != "Connected")
									{
										UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
										return;
									}
									UserDialogs.Instance.ShowLoading("Loading...");
									await Task.Delay(100);
									var AssetDetailsViewModel = new AssetDetailsViewModel();
									await AssetDetailsViewModel.GetActualAssetImage(item);

									await Navigation.PushAsync(new NewAssetsDetailPage(item.Position_no, item, AssetDetailsViewModel));
									UserDialogs.Instance.HideLoading();
								};
								it.GestureRecognizers.Add(bigt);
								x += 80;
								i++;
								CountOfImage++;
							}
							position += 20 + 50;
						}
						else
						{
							var it = new CachedImage()
							{
								WidthRequest = 80,
								HeightRequest = 80,
								CacheDuration = TimeSpan.FromDays(30),
								DownsampleToViewSize = true,
								RetryCount = 0,
								RetryDelay = 250,
								TransparencyEnabled = false,
								Aspect = Aspect.AspectFit,
								Source = ImageSource.FromFile("noimage.gif"),
							};
							relativeLayouts.Children.Add(it);
							//it = MyUILibrary.AddCachedImage(relativeLayouts, it, x, position + 40, 80, 80, Aspect.Fill);
							position += 100 + 20;
						}
					}
					else
					{
						var it = new CachedImage()
						{
							WidthRequest = 80,
							HeightRequest = 80,
							CacheDuration = TimeSpan.FromDays(30),
							DownsampleToViewSize = true,
							RetryCount = 0,
							RetryDelay = 250,
							TransparencyEnabled = false,
							Aspect = Aspect.AspectFit,
							Source = ImageSource.FromFile("noimage.gif"),
						};
						relativeLayouts.Children.Add(it);
						//it = MyUILibrary.AddCachedImage(relativeLayouts, it, x, position + 40, 80, 80, Aspect.Fill);
						position += 100 + 20;
					}
				}

				else
				{
					var it = new CachedImage()
					{
						WidthRequest = 80,
						HeightRequest = 80,
						CacheDuration = TimeSpan.FromDays(30),
						DownsampleToViewSize = true,
						RetryCount = 0,
						RetryDelay = 250,
						TransparencyEnabled = false,
						Aspect = Aspect.AspectFit,
						Source = ImageSource.FromFile("noimage.gif"),
					};
					it = MyUILibrary.AddCachedImage(relativeLayout, it, x, position + 40, 80, 80, Aspect.Fill);
					position += 100 + 20;
				}
				var lblHelp = new Label { Text = "Tap on image to Edit & delete Asset", HorizontalOptions = LayoutOptions.CenterAndExpand };
				var btnAdd = new Xamarin.Forms.Button
				{
					Text = "   Add New Image   ",
					BackgroundColor = Color.Red,
					TextColor = Color.White,
					FontSize = 15,
					HorizontalOptions = LayoutOptions.CenterAndExpand
				};
				////var lblHelp = MyUILibrary.AddLabel(relativeLayouts, "Tap on image to Edit & delete Asset", 20, position + 110, w, 50, Color.Red, 17);
				////var btnAdd = MyUILibrary.AddButton(relativeLayouts, "Add New Image", 60, position + 130, 200, 40, Color.Red, Color.Gray, Color.White, 15);
				var btnlayout = new StackLayout { VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };

				btnlayout.Children.Add(lblHelp);
				btnlayout.Children.Add(btnAdd);

				mainlayoutGallery = new StackLayout { Padding = 5, VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };

				mainlayoutGallery.Children.Add(relativeLayouts);
				mainlayoutGallery.Children.Add(btnlayout);
				MyUILibrary.AddLayout(relativeLayout, mainlayoutGallery, 0, position - 25, w, h / 2 - 50);
				//if (ViewModel.ImageList.Count() < 4)

				//{

				//	lblHelp = MyUILibrary.AddLabel(relativeLayout, "Tap on image to Edit & delete Asset", 20, position + 70, w, 50, Color.Red, 15);
				//	btnAdd = MyUILibrary.AddButton(relativeLayout, "Add New Image", (w - newx40) / 2 - 10, position + 100, 200, 40, Color.Red, Color.Gray, Color.White, 15);
				//}
				//else { 

				//lblHelp = MyUILibrary.AddLabel(relativeLayout, "Tap on image to Edit & delete Asset", 20, position + 130, w, 50, Color.Red, 15);
				//	btnAdd = MyUILibrary.AddButton(relativeLayout, "Add New Image", (w - newx40) / 2 - 10, position + 155, 200, 40, Color.Red, Color.Gray, Color.White, 15);

				//}
				var a = await ViewModel.GetDeviceAssets(device.device_idx);
				if (ViewModel.AssetsList != null && AssetViewModel != null)
				{
					countAssets = ViewModel.AssetsList.Count;
					btnAdd.BindingContext = AssetViewModel;
				}
				AssetViewModel._navigation = this.Navigation;
				AssetViewModel.Device = device;
				AssetViewModel.CountAsset = countAssets;
				btnAdd.Command = AssetViewModel.TakePicture;

				position += 100 + 10;
				position += 10;
			}
			catch (Exception ex)
			{
				//await UserDialogs.Instance.AlertAsync(ex.Message, ex.StackTrace, "ok");
				//var a = ex.StackTrace;
			}

			//UserDialogs.Instance.HideLoading();
		}


		private async Task<Image> ModeltoImage(DeviceAssetsModel obj)
		{
			Image img = new Image();
			try
			{
				img = (BytesArraytoImage(obj.Deviceimage_thumbnail));

			}
			catch { }
			return img;
		}

		private Image BytesArraytoImage(byte[] stream)
		{
			Image img = new Image();
			try
			{
				byte[] imagedata = stream;
				img.Source = ImageSource.FromStream(() => new MemoryStream(imagedata));
			}
			catch { }
			return img;
		}
		public async void GetPopupofAssetsImage(bool isopen)
		{
			try
			{
				//Xamarin.Forms.RelativeLayout relativeLayouts = new Xamarin.Forms.RelativeLayout();
				Xamarin.Forms.StackLayout relativeLayouts = new Xamarin.Forms.StackLayout();
				relativeLayouts.VerticalOptions = LayoutOptions.StartAndExpand;
				int z = 10;
				double position = 0;
				double newx20 = MyUiUtils.getPercentual(w, 20);
				double newx40 = MyUiUtils.getPercentual(w, 40);
				double newx60 = MyUiUtils.getPercentual(w, 60);
				double newx80 = MyUiUtils.getPercentual(w, 80);

				var x = 10;
				var i = 0;
				var lblname = new Label { Text = "Device:", TextColor = Color.Black, FontSize = 18, FontAttributes = FontAttributes.Bold, WidthRequest = 75, };
				//MyUILibrary.AddLabel(relativeLayout, "Device:", x, position + 10, w, 50, Color.Black, 16);
				var LblDvice = new Label { TextColor = Color.Black, FontSize = 18, FontAttributes = FontAttributes.Bold, HorizontalOptions = LayoutOptions.StartAndExpand };
				LblDvice.LineBreakMode = LineBreakMode.WordWrap;
				if (MyController.Roll_id != 8)
				{
					if (device != null && (!string.IsNullOrEmpty(device.FriendlyName)))
						LblDvice.Text = "Device: " + device.FriendlyName.ToString();
					else
						LblDvice.Text = "Device: " + "Asset Images";
				}
				else
				{
					LblDvice.Text = "Device: " + "Asset Images";
				}
				var CloseIcon = new Image { Source = "CloseIcon.png", HeightRequest = 25, WidthRequest = 25, HorizontalOptions = LayoutOptions.EndAndExpand, VerticalOptions = LayoutOptions.CenterAndExpand };

				StackLayout st = new StackLayout() { Padding = new Thickness(0, 10, 0, 0), Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.FillAndExpand, VerticalOptions = LayoutOptions.StartAndExpand };
				st.Children.Add(LblDvice);
				st.Children.Add(CloseIcon);
				relativeLayouts.Children.Add(st);
				var layoutGllry1 = new StackLayout { Orientation = StackOrientation.Horizontal, VerticalOptions = LayoutOptions.StartAndExpand };
				var layoutGllry2 = new StackLayout { Orientation = StackOrientation.Horizontal, VerticalOptions = LayoutOptions.StartAndExpand };

				//MyUILibrary.AddLayout(relativeLayouts, st, 12, position, MyController.ScreenWidth - 100, 50);
				var popupLayouts = this.Content as CustomPopup;
				if (ViewModel != null && ViewModel.AssetsList != null)
				{
					countAssets = ViewModel.AssetsList.Count;
					if (ViewModel.ImageList != null)
					{
						if (ViewModel.ImageList.Count() > 0)
						{
							int CountOfImage = 1;
							foreach (var item in ViewModel.AssetsList)
							{
								var it = new CachedImage()
								{
									WidthRequest = MyController.ScreenWidth/5+5,
									HeightRequest = MyController.ScreenWidth / 5,
									CacheDuration = TimeSpan.FromDays(30),
									DownsampleToViewSize = true,
									RetryCount = 0,
									RetryDelay = 250,
									TransparencyEnabled = false,
									Aspect = Aspect.AspectFit,
									Source = ImageSource.FromFile("noimage.gif"),
								};
								var layout = new Xamarin.Forms.RelativeLayout();
								layout.Padding = 2;
								layout.Children.Add(it, Constraint.Constant(0), Constraint.Constant(0));
								layout.BackgroundColor = Color.White;

								var sou = await ModeltoImage(item);
								it.Source = sou.Source as ImageSource;
								var frm = new Frame { Padding = 1, HasShadow = false, BackgroundColor = Color.White };
								frm.Content = it;
								if (CountOfImage < 5)
								{
									layoutGllry1.Children.Add(frm);
									//frm = MyUILibrary.AddnewFrame(relativeLayouts, frm, x - 5, position + 40, 80, 80);
								}
								else {
									layoutGllry2.Children.Add(frm);
									//frm = MyUILibrary.AddnewFrame(relativeLayouts, frm, z-5, position + 100, 80, 80);
									//z += 50 + 40;
									z += 80;
								}
								relativeLayouts.Children.Add(layoutGllry1);
								relativeLayouts.Children.Add(layoutGllry2);

								TapGestureRecognizer bigt = new TapGestureRecognizer();
								bigt.Tapped += async (object sender, EventArgs e) =>
								{
									popupLayouts.DismissPopup();
									var networkConnection = DependencyService.Get<INetworkConnection>();
									networkConnection.CheckNetworkConnection();
									var networkStatus = networkConnection.IsConnected ? "Connected" : "Not Connected";
									if (networkStatus != "Connected")
									{
										UserDialogs.Instance.Alert("Please check your internet connection.", "Alert", "OK");
										return;
									}
									UserDialogs.Instance.ShowLoading("Loading...");
									await Task.Delay(100);
									var AssetDetailsViewModel = new AssetDetailsViewModel();
									await AssetDetailsViewModel.GetActualAssetImage(item);

									await Navigation.PushAsync(new NewAssetsDetailPage(item.Position_no, item, AssetDetailsViewModel));
									UserDialogs.Instance.HideLoading();
								};
								it.GestureRecognizers.Add(bigt);
								x += 80;
								i++;
								CountOfImage++;
							}
							position += 20 + 50;
						}
						else
						{
							var it = new CachedImage()
							{
								WidthRequest = 80,
								HeightRequest = 80,
								CacheDuration = TimeSpan.FromDays(30),
								DownsampleToViewSize = true,
								RetryCount = 0,
								RetryDelay = 250,
								TransparencyEnabled = false,
								Aspect = Aspect.AspectFit,
								Source = ImageSource.FromFile("noimage.gif"),
							};
							relativeLayouts.Children.Add(it);
							//it = MyUILibrary.AddCachedImage(relativeLayouts, it, x, position + 40, 80, 80, Aspect.Fill);
							position += 100 + 20;
						}
					}
					else
					{
						var it = new CachedImage()
						{
							WidthRequest = 80,
							HeightRequest = 80,
							CacheDuration = TimeSpan.FromDays(30),
							DownsampleToViewSize = true,
							RetryCount = 0,
							RetryDelay = 250,
							TransparencyEnabled = false,
							Aspect = Aspect.AspectFit,
							Source = ImageSource.FromFile("noimage.gif"),
						};
						relativeLayouts.Children.Add(it);
						//it = MyUILibrary.AddCachedImage(relativeLayouts, it, x, position + 40, 80, 80, Aspect.Fill);
						position += 100 + 20;
					}
				}
				else
				{
					var it = new CachedImage()
					{
						WidthRequest = 80,
						HeightRequest = 80,
						CacheDuration = TimeSpan.FromDays(30),
						DownsampleToViewSize = true,
						RetryCount = 0,
						RetryDelay = 250,
						TransparencyEnabled = false,
						Aspect = Aspect.AspectFit,
						Source = ImageSource.FromFile("noimage.gif"),
					};
					relativeLayouts.Children.Add(it);
					//it = MyUILibrary.AddCachedImage(relativeLayouts, it, x, position + 40, 80, 80, Aspect.Fill);
					position += 100 + 20;
				}
				var lblHelp = new Label { Text = "Tap on image to Edit & delete Asset" , HorizontalOptions = LayoutOptions.CenterAndExpand		};
				var btnAdd = new Xamarin.Forms.Button
				{
					Text = "   Add New Image   ",
					BackgroundColor = Color.Red,
					TextColor = Color.White,
					FontSize = 15,
					HorizontalOptions = LayoutOptions.CenterAndExpand
				};
				//var lblHelp = MyUILibrary.AddLabel(relativeLayouts, "Tap on image to Edit & delete Asset", 20, position + 110, w, 50, Color.Red, 17);
				//var btnAdd = MyUILibrary.AddButton(relativeLayouts, "Add New Image", 60, position + 130, 200, 40, Color.Red, Color.Gray, Color.White, 15);
				var btnlayout = new StackLayout { VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };

				btnlayout.Children.Add(lblHelp);
				btnlayout.Children.Add(btnAdd);

				var mainlayout = new StackLayout { Padding = 5, VerticalOptions = LayoutOptions.FillAndExpand, HorizontalOptions = LayoutOptions.FillAndExpand };
				mainlayout.Children.Add(relativeLayouts);
				mainlayout.Children.Add(btnlayout);


				//var a = await ViewModel.GetDeviceAssets(device.device_idx);
				if (ViewModel.AssetsList != null && AssetViewModel != null)
				{
					countAssets = ViewModel.AssetsList.Count;
					btnAdd.BindingContext = AssetViewModel;
				}
				AssetViewModel._navigation = this.Navigation;
				AssetViewModel.Device = device;
				AssetViewModel.CountAsset = countAssets;


				position += 100 + 10;
				position += 10;

				if (Device.Idiom == TargetIdiom.Phone)
				{
					//PaddingMain = 8;
					pddingH = .110;
					paddingW = .8;
				}
				if (Device.Idiom == TargetIdiom.Tablet)
				{
					//PaddingMain = 40;
					pddingH = .40;
					paddingW = .5;

				}
				;



				//btnAdd.Command = AssetViewModel.TakePicture;
				btnAdd.Clicked += async (sender, e) =>
				{
					
						if (ViewModel.ImageList.Count() < 8)
						{
							popupLayouts.DismissPopup();
						}



					//TakePictureViewModel viewModel = new TakePictureViewModel();

					await AssetViewModel.ExecuteUserImageSelectionCommand();
					//ViewModel.();

				};
				TapGestureRecognizer bigts = new TapGestureRecognizer();
				bigts.Tapped += async (object sender, EventArgs e) =>
				{
					popupLayouts.DismissPopup();
				};

				CloseIcon.GestureRecognizers.Add(bigts);
				if (popupLayouts.IsPopupActive)
				{
					//if (isopen)
					//{
					//	//popupLayouts.DismissPopup();
					//	var view = new Frame
					//	{
					//		Padding = new Thickness(0, 0, 0, 0),
					//		HasShadow = false,
					//		OutlineColor = Color.Gray,
					//		HeightRequest = MyController.ScreenHeight / 2,
					//		WidthRequest = MyController.ScreenWidth - 60,
					//		VerticalOptions = LayoutOptions.FillAndExpand,
					//		HorizontalOptions = LayoutOptions.FillAndExpand,
					//		BackgroundColor = Color.FromHex("f2f2f2"),
					//		Content = relativeLayouts
					//	};



					//	this.ToolbarItems.Clear();
					//	NavigationPage.SetHasBackButton(this, false);
					//	popupLayouts.ShowPopup(view);
					//}

				}
				else {


					var view = new Frame
					{
						Padding = new Thickness(0, 0, 0, 0),
						HasShadow = false,
						OutlineColor = Color.Gray,
						HeightRequest = MyController.ScreenHeight / 2+50,
						WidthRequest = MyController.ScreenWidth - 20,
						VerticalOptions = LayoutOptions.FillAndExpand,
						HorizontalOptions = LayoutOptions.FillAndExpand,
						BackgroundColor = Color.FromHex("f2f2f2"),
						Content = mainlayout
					};



					this.ToolbarItems.Clear();
					NavigationPage.SetHasBackButton(this, false);
					popupLayouts.ShowPopup(view);
				}

			}
			catch { }

		}
		//static  byte[] Decompress(byte[] data)
		//{
		//	using (var compressedStream = new MemoryStream(data))
		//	using (var zipStream = new  GZipStream(compressedStream, CompressionMode.Decompress))
		//	using (var resultStream = new MemoryStream())
		//	{
		//		zipStream.CopyTo(resultStream);
		//		return resultStream.ToArray();
		//	}
		//}

	}
}

