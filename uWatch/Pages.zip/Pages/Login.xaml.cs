﻿using System;
using Xamarin.Forms;
using UwatchPCL;
using uWatch;
using UwatchPCL.Helpers;
using System.Threading.Tasks;
using Acr.UserDialogs;
#if __ANDROID__
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
#endif

#if __ANDROID__
using Android.OS;
#endif


namespace uWatch
{
	public partial class Login : ContentPage
	{
		const int rowHeight = 190;
		RelativeLayout relativeLayout;
		ScrollView scrollview;

		int w = MyController.VirtualWidth;
		int H = MyController.VirtualHeight;

		public LoginViewModel ViewModel;
		public Button btnLogin;
		public Image Img_TopRedLine = null;
		public Image imgIcon = null;

		public Entry txtUsername;
		public Entry txtPassword;

		public double newx20 = 0;

		public Login ()
		{
			try
			{
			InitializeComponent ();

			BindingContext = new LoginViewModel(Navigation);


			#if __ANDROID__
				MyController.Device_OS = Device.OS.ToString();
			#endif
			#if __IOS__
				MyController.Device_OS = Device.OS.ToString();
			#endif
				}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}
		}

		#if __ANDROID__
		async Task<bool> CheckLocationPermisions()
		{
			var results = false;
			try
			{
				var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Plugin.Permissions.Abstractions.Permission.Location);
				if (status != PermissionStatus.Granted)
				{
					if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Plugin.Permissions.Abstractions.Permission.Location))
					{
						await DisplayAlert("Need location", "App want to use the location service for this App.", "OK");
					}

					var r = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Plugin.Permissions.Abstractions.Permission.Location });
					status = r[Plugin.Permissions.Abstractions.Permission.Location];
				}
				if (status == PermissionStatus.Granted)
				{
					results = true;
				}
				else if (status != PermissionStatus.Unknown)
				{
					await DisplayAlert("Location Denied", "Can not continue, without location service. try again.", "OK");
				}
			}
			catch (Exception ex)
			{
				results = false;
			}
			return results;
		}
		#endif

		protected override async void OnAppearing()
		{
			try
			{

			
#if __ANDROID__
			var s = await CheckLocationPermisions();
			if (s)
			{
				ViewModel = new LoginViewModel(this.Navigation);
				this.BackgroundColor = Color.White;
				BindingContext = ViewModel;
				SetLayout();
			}
			else
			{
				Process.KillProcess(Process.MyPid());
			}
			base.OnAppearing();
#endif
#if __IOS__
			ViewModel = new LoginViewModel(this.Navigation);
			this.BackgroundColor = Color.White;
			BindingContext = ViewModel;
			SetLayout();
			base.OnAppearing();
#endif
				}
			catch (Exception ex)
			{
				MyController.ErrorManagement(ex.Message);
			}

		}

		protected override void OnDisappearing()
		{
			base.OnDisappearing();
		}

		private void SetLayout()
		{
			relativeLayout = new RelativeLayout();
			relativeLayout.BackgroundColor = Color.White;
			AddLayout();
			scrollview = new ScrollView();
			scrollview.Content = relativeLayout;
			Content = scrollview;
		}

		private async void AddLayout()
		{
			double position = 0;
			newx20 = MyUiUtils.getPercentual(w, 20);
			double newx40 = MyUiUtils.getPercentual(w, 40);
			double newx60 = MyUiUtils.getPercentual(w, 60);
			double newx80 = MyUiUtils.getPercentual(w, 80);

			var imgTopRedLine = MyUILibrary.AddImage (relativeLayout, "red_line.png", 0, position+12, w, 10,Aspect.Fill);
			var imgBottomRedLine = MyUILibrary.AddImage (relativeLayout, "red_line.png", 0, H-36, w, 10,Aspect.Fill);
			Device.OnPlatform 
			(
				iOS: () => 
				{
					imgTopRedLine.TranslationY = position+12;

				}
			);
			
			position += 3;

			MyUILibrary.AddImage (relativeLayout, "uwatch_logo.png", (w-newx40)/2, position+40, newx40, newx40, Aspect.AspectFit);
			position +=20 + newx40;

			var lblLogin = MyUILibrary.AddLabel (relativeLayout, "Enter your login Details", 0, position, w,55, Color.Black, 18);
			position += 55;
			lblLogin.HorizontalOptions = LayoutOptions.CenterAndExpand;

			txtUsername = MyUILibrary.AddEntry (relativeLayout, "", "Username", (w - newx80) / 2, position + 20, newx80,45, Color.Black, Keyboard.Default, TextAlignment.Start,fontsize:15);
			position += 25 + 25;
			txtUsername.SetBinding(Entry.TextProperty, new Binding("Username", BindingMode.TwoWay));
			if (ViewModel.Username.Length == 0)
			{
				ViewModel.Username = txtUsername.Text;
			}

			txtPassword = MyUILibrary.AddEntry (relativeLayout, "", "Password", (w - newx80) / 2, position + 20, newx80,45, Color.Black, Keyboard.Default, TextAlignment.Start, true, fontsize:15);
			position += 25 + 25;
			txtPassword.SetBinding(Entry.TextProperty, new Binding("Password", BindingMode.TwoWay));
			if (ViewModel.Password.Length == 0)
			{
				ViewModel.Password = txtPassword.Text;
			}

			var imgremember = MyUILibrary.AddImage(relativeLayout, "Checkbox.png", (w - newx80) / 2+10, position + 20, 20, 20,Aspect.AspectFit);
			if (!Settings.IsRememberMe)
			{
				imgremember.Source = ImageSource.FromFile("Checkbox.png");
				Settings.IsRememberMe = false;
			}
			else
			{
				imgremember.Source = ImageSource.FromFile("CheckBoxTick.png");
				Settings.IsRememberMe = true;
			}


			TapGestureRecognizer TRemember = new TapGestureRecognizer();
			TRemember.Tapped += (object sender, EventArgs e) =>
			{
				if ((imgremember.Source as FileImageSource).File == "CheckBoxTick.png")
				{
					imgremember.Source = ImageSource.FromFile("Checkbox.png");
					Settings.IsRememberMe = false;
				}
				else
				{
					imgremember.Source = ImageSource.FromFile("CheckBoxTick.png");
					Settings.IsRememberMe = true;
				}
			};
			imgremember.GestureRecognizers.Add(TRemember);
			MyUILibrary.AddLabel(relativeLayout, "Remember me", ((w - newx80) / 2) + 40, position + 20, newx80, 55, Color.Black, 15);


			btnLogin  = MyUILibrary.AddButton (relativeLayout, "Login", (w - newx60) / 2, position + 80, newx60, 40, Color.Red, Color.Red, Color.White,15);
			position += 80 + 40;
			btnLogin.Command = ViewModel.LoginCommand;


			var lblforgot = MyUILibrary.AddLabel (relativeLayout, "Forgot your password?", 0, position+20, w,55, Color.Blue, 15);
			TapGestureRecognizer TForgot = new TapGestureRecognizer();
			TForgot.Tapped += async (object sender, EventArgs e) =>
			{
				UserDialogs.Instance.ShowLoading("Loading...", MaskType.Gradient);
				await Navigation.PushModalAsync(new ForgotPage());
				UserDialogs.Instance.HideLoading();
			};
			lblforgot.GestureRecognizers.Add(TForgot);
			position += 20 + 55;
			lblforgot.HorizontalOptions = LayoutOptions.CenterAndExpand;

		}

	}
}

	