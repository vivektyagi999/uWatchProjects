﻿using System;
using System.Collections.Generic;
//using System.Net.Http;
//using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Xml;
using UwatchPCL;
using Xamarin.Forms;
using Xamarin.Forms.Maps;

namespace uWatch
{
	public partial class MemberMapPage : ContentPage
	{

		public MemberMapPage(List<LatLong> items)
		{


			getPin(items);

		}
		public async void getPin(List<LatLong> items)
		{
			
			InitializeComponent();
			foreach (var pinPos in items)
			{

				var pos = new Position(Convert.ToDouble(pinPos.lat), Convert.ToDouble(pinPos.lng));
				var pin = new Pin
				{
					Type = PinType.Place,
					Position = pos,
				};
				//	var possibleAddresses = geoCoder.GetAddressesForPositionAsync(pos).Result;
				//foreach (var address in item.results)
				//	{
				//pin.Address += address + "\n";
				pin.Label = pos.Latitude.ToString() + "," + pos.Longitude.ToString();
				//}
				this.MyMap.Pins.Add(pin);
				this.MyMap.MoveToRegion(MapSpan.FromCenterAndRadius(pos, Distance.FromMiles(1.0)));
				//IsMap = true;

			}
		}
	}
	public class LatLong
	{
		public double lat { get; set; }
		public double lng { get; set; }
	}
}
	//public string getLatLong(string Address, string Zip)
	//{
	//	string latlong = "", address = "";
	//	if (Address != string.Empty)
	//	{
	//		address = "http://maps.googleapis.com/maps/api/geocode/xml?address=" + Address + "&sensor=false";
	//	}
	//	else
	//	{
	//		address = "http://maps.googleapis.com/maps/api/geocode/xml?components=postal_code:" + Zip.Trim() + "&sensor=false";
	//	}
	//	var result = new System.Net.WebClient().DownloadString(address);
	//	XmlDocument doc = new XmlDocument();
	//	doc.LoadXml(result);
	//	XmlNodeList parentNode = doc.GetElementsByTagName("location");
	//	var lat = "";
	//	var lng = "";
	//	foreach (XmlNode childrenNode in parentNode)
	//	{
	//		lat = childrenNode.SelectSingleNode("lat").InnerText;
	//		lng = childrenNode.SelectSingleNode("lng").InnerText;
	//	}
	//	latlong = Convert.ToString(lat) + "," + Convert.ToString(lng);
	//	return latlong;
	//}

	//}

	

